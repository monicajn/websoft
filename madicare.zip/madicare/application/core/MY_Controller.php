<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {
    
        public $login;
        public $CI;
        public $_month;
        public $_access;
        public function __construct()
	{
        parent::__construct();
        
	   if($this->session->userdata('id')){  
         }else{
     	 $this->session->set_flashdata('error', 'please login to access your account');
     	   redirect('login');
      }
          
          $this->login = array(
              'id'     =>$this->session->userdata('id'),
              'name'   =>$this->session->userdata('name'),
              'userID' =>$this->session->userdata('userID'),
              'email'  => $this->session->userdata('email'),
              'type'   => $this->session->userdata('type'),
            );
          if($this->session->userdata('access')!=''){
            $this->_access = explode(',', $this->session->userdata('access'));
          }else{
            $this->_access = '';
         }
          $this->_month  = array('01'=>"January",'02'=>"February",'03'=>"March",
                              '04'=> "April",'05'=>"May",'06'=>"June",'07'=>"July",
                              '08'=>"August",'0n'=>"September",'10'=>"October",
                              '11'=>"November",'12'=>"December");
       
          date_default_timezone_set('Asia/Kolkata');
          $this->CI = & get_instance();
         
      }

  function checkPermission($role){
    if($this->login['type']=='admin' || ($this->login['type']=='user' && in_array($role,$this->_access))) {
       return true;
    }else{
      return false;
    }
  }
      
  function upload_pic($name,$folder) {
      $this->load->helper('form');
      $config['upload_path'] = 'assets/'.$folder.'/';
      $config['allowed_types'] = 'gif|jpg|png|jpeg';
                  //$config['encrypt_name'] = TRUE;
            $config['image_library'] = 'gd2';
                  $config['maintain_ratio']  = TRUE;
      $config['max_size'] = '30000';
      $config['max_width'] = '102400';
      $config['max_height'] = '76800';
                  $new_name = date('d').time();
            $config['file_name'] = $new_name;
      $this->load->library('upload', $config);
      $this->upload->initialize($config);
      if (!$this->upload->do_upload($name)) {
      return $data = array('msg' => $this->upload->display_errors());
      } else { //else, set the success message
        $data = array('msg' => "success");
        $data['upload_data'] = $this->upload->data();
        $this->load->library('image_lib');
        //here is the second thumbnail, notice the call for the initialize() function again
        return $data['upload_data']['file_name'];
      }
      //resize img
    return '';
  }
        
      function format_date($date,$format){
        $_date=date_create($date);
        return date_format($_date,$format);
      }

      function createFormatDate($date,$format,$newformat){
         $_date = DateTime::createFromFormat($format, $date);
         $_dd = $_date->format($newformat);
         return $_dd;
      }
      
       function format_number($number='',$no){
          return number_format( $number, $no );
      }
      
      
    
          
         public function getRowCount($array){
                if(is_array($array)){
                   return  count($array);
                }else{
                   echo 'Pass valid variable array';
                }
          }
         function array_flatten($array) { 
                if (!is_array($array)) { 
                  return false; 
                } 
                $result = array(); 
                foreach ($array as $key => $value) { 
                  if (is_array($value)) { 
                    $result = array_merge($result, $this->array_flatten($value)); 
                  } else { 
                    $result[$key] = $value; 
                  } 
                } 
                return $result; 
          } 

          function getRandom($start,$length){
             $str = mt_rand()."5".time()."3847".date('Ymd')."1029".time()."6".mt_rand();
             $str = substr(str_shuffle($str),$start,$length);
             return $str;
          }
           function getRandomChar($start,$length){
             $str = mt_rand()."yt5zux".time()."vabwcd3847".date('Ymd')."efghi1029nmlkj".time()."6psorq".mt_rand();
             $str1 = substr(str_shuffle($str),$start,$length);
             return $str1;
          }

          public function download($filename){
             
            //download file from directory
            $file = 'assets/uploads/'.$filename; 
            //download file from directory
            force_download($file, NULL);
             }
         
          
	
}

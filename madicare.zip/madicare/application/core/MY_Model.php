<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Model extends CI_Model {
      
     public $table=null;
        public $primary_key;
        public $fillable = array('id');
        
       public function __construct(){
            parent::__construct();
	}
	
        
        public function insert($post)
	{
            $this->db->insert($this->table,$post);
            return  $this->db->insert_id();
        }
        public function delete($array)
	{   
             $this->db->where($array);
             $this->db->delete($this->table);
             return true;
        }
        
        public function update($whr,$post)
	     {   
            $this->db->where($whr);
            $this->db->update($this->table,$post); 
            return true;
        }
        
	public function getResult($select=array('*'),$where='',$join='',$groupBy='',$orderby='',$limit='')
	{  	  
	   $sel = implode(',',$select);
           $this->db->select($sel);
        if($where!=''){
        
        	foreach ($where as $key => $value) {
        		 $this->db->where($key,$value);
        	}	
        }
         if($join!=''){
        	foreach ($join as $key => $value) {
        		$this->db->join($key,$value,'left');
        	}	
        }
         if($groupBy!='' && is_array($groupBy)){
        	foreach ($groupBy as $group) {
        		$this->db->group_by($group); 
        	}	
        }
        if($orderby!=''){
        	foreach ($orderby as $key => $value) {
        		$this->db->order_by($key,$value);
        	}	
        }
        if($limit!=''){
        	$this->db->limit($limit);
        }
       return $this->db->get($this->table)->result_array();
	}

   public function getRow($select='',$where='',$groupBy='',$orderby='',$limit=''){
   	   $sel = implode(',',$select);
        $this->db->select($sel);
        if($where!=''){
        	$this->db->where($where);
        }
        if($groupBy!='' && is_array($groupBy)){
        	foreach ($groupBy as $group) {
        		$this->db->group_by($group); 
        	}	
        }
        if($orderby!=''){
        	foreach ($orderby as $key => $value) {
        		$this->db->order_by($key,$value);
        	}	
        }
        if($limit!=''){
        	$this->db->limit($limit);
        }
       return $this->db->get($this->table)->result_array(); 
   }

    public function getOne($column='',$where='',$orderby='',$groupBy='',$limit=''){
   	   $this->db->select($column);
        if($where!=''){
        	$this->db->where($where);
        }
        if($groupBy!='' && is_array($groupBy)){
        	foreach ($groupBy as $group) {
        		$this->db->group_by($group); 
        	}	
        }
        if($orderby!=''){
        	foreach ($orderby as $key => $value) {
        		$this->db->order_by($key,$value);
        	}	
        }
        if($limit!=''){
        	$this->db->limit($limit);
        }
       return $this->db->get($this->table)->row()->$column; 
   }
    public function getMinMax($param='',$column='',$where='',$join='',$orderby='',$groupBy=''){
   	  
          if($param=='MAX'){
               $this->db->select_max($column);
           }else if($param=='MIN'){
                $this->db->select_min($column);
           }
          
        if($where!=''){
        	$this->db->where($where);
        }
         if($join!=''){
        	foreach ($join as $key => $value) {
        		$this->db->join($key,$value);
        	}	
        }
        if($groupBy!='' && is_array($groupBy)){
        	foreach ($groupBy as $group) {
        		$this->db->group_by($group); 
        	}	
        }
        
        if($orderby!=''){
        	foreach ($orderby as $key => $value) {
        		$this->db->order_by($key,$value);
        	}	
        }
        
       return $this->db->get($this->table)->row()->$column; 
   }
   
   
}

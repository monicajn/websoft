<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Claim extends MY_Controller {

	public function __construct()
	{
          parent::__construct();
           if($this->CI->checkPermission('cl')){
             }else{
              $this->session->set_flashdata('error', 'please login to access your account');
             redirect('login');
            }
           $this->load->model(array('Doctors_model','Cptcode_model','Payment_model','Insurance_model','Patient_model','Claim_model','Cities_model','States_model','Countries_model'));
     $this->load->library('PHPExcel');
        }
    
	public function index()
	{         $join=array('patients'=>'patients.id=claims.patient_id',
                        'insurance'=>'insurance.id=claims.insurance',
                        'cptcode'=>'cptcode.id=claims.cpt_code'
                      );
            $template['claims'] = $this->Claim_model->getResult(array('tbl_patients.fname as pfname','tbl_patients.lname as plname','insurance.name AS insurancename','cptcode.code as code','claims.*'),'',$join);
            $template['title']='Insurance Claim';
            $template['subtitle']='List-Claim';
            $template['theme']='theme/claim';
            $template['ancher']='claim';
            
            if(isset($_POST['search'])){
              $whr=array();
              if(!empty($_POST['date'])){
              $_date = DateTime::createFromFormat('m/d/Y', $_POST['date']);
              $date  = $_date->format('Y-m-d');
              $whr['date'] =$date;
            }
             if(!empty($_POST['dos'])){
              $_dos = DateTime::createFromFormat('m/d/Y', $_POST['dos']);
              $dos  = $_dos->format('Y-m-d');
              $whr['claims.date_of_service'] =$dos;
              }
              if($_POST['status']!='all'){
                 $whr['claims.status'] =$_POST['status'];
              }
              if($_POST['month']!='all'){
                 $whr['claims.month'] =$_POST['month'];
              }
              if($_POST['month']!='all'){
                 $whr['claims.month'] =$_POST['month'];
              }
              if(count($whr)>0){
                    $join=array('patients'=>'patients.id=claims.patient_id',
                        'insurance'=>'insurance.id=claims.insurance',
                        'cptcode'=>'cptcode.id=claims.cpt_code'
                      );
                     $template['claims'] = $this->Claim_model->getResult(array('tbl_patients.fname as pfname','tbl_patients.lname as plname','insurance.name AS insurancename','cptcode.code as code','claims.*'),$whr,$join);
                  }
               }
           // echo $this->db->last_query();
            if($this->CI->checkPermission('cl_4')){ 
              $template['page']='claim/list';
            }else{
              $template['page']='access/index';
            }  
	         $this->load->view('template',$template);
	}
  public function add()
  {         if(isset($_POST['save'])){
               $claimData = array(
                            'date'=>$this->createFormatDate($_POST['date'],'m/d/Y','Y-m-d'),
                            'transaction_type'=>$_POST['transaction_type'],
                            'date_of_service'=>$this->createFormatDate($_POST['date_of_service'],'m/d/Y','Y-m-d'),
                            'patient_id'=>$_POST['patient_id'],
                            'doctor_id'=>$_POST['doctor_id'],
                            'month'=>$_POST['month'],
                            'insurance'=>$_POST['insurance'],
                            'cpt_code'=>$_POST['cpt_code'],
                            'description'=>$_POST['description'],
                            'quantity'=>$_POST['quantity'],
                            'rate'=>$_POST['rate'],
                            'total_invoice'=>$_POST['total_invoice'],
                            'amount_received'=>$_POST['amount_received'],
                            'balance'=>$_POST['balance'],
                            'addedOn'=>date('Y-m-d H:i:s'),
                            'updateOn'=>date('Y-m-d H:i:s'),
                           );
              
               $cid = $this->Claim_model->insert($claimData);
                  if($_POST['by_pt']!='' && $_POST['by_pt']>0){
                     $payData = array(
                          'claim_id'=>$cid,
                          'amount'=>$_POST['by_pt'],
                          'paid_by'=>'patient',
                          'date_time'=>date('Y-m-d H:i:s'),
                          'rc_by'=>$this->login['id']
                        );
                       $this->Payment_model->insert($payData);
                    }
                   if($_POST['by_claim']!='' && $_POST['by_claim']>0){
                     $payData = array(
                          'claim_id'=>$cid,
                          'amount'=>$_POST['by_claim'],
                          'paid_by'=>'claim',
                          'date_time'=>date('Y-m-d H:i:s'),
                          'rc_by'=>$this->login['id']
                        );
                      $this->Payment_model->insert($payData);
                    }
              if($cid>0){

                $this->session->set_flashdata('success', 'Claim Added successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('claim');
             }   
            $template['patients'] = $this->Patient_model->getResult(array('id','fname','lname','mname'));
            $template['doctors'] = $this->Doctors_model->getResult(array('*'));
            $template['insurance'] = $this->Insurance_model->getResult(array('*'));
            $template['cpts'] = $this->Cptcode_model->getResult(array('*'));
            $template['title']='Insurance Claim';
            $template['subtitle']='Add-Claim';
            $template['theme']='theme/claim';
            $template['ancher']='claim';
            if($this->CI->checkPermission('cl_1')){ 
              $template['page']='claim/add';
            }else{
              $template['page']='access/index';
            } 
             
           $this->load->view('template',$template);
  }

  public function edit($id){
            if(isset($_POST['save'])){
              $cid = $_POST['id'];
               $claimData = array(
                            'date'=>$this->createFormatDate($_POST['date'],'m/d/Y','Y-m-d'),
                            'transaction_type'=>$_POST['transaction_type'],
                            'date_of_service'=>$this->createFormatDate($_POST['date_of_service'],'m/d/Y','Y-m-d'),
                            'patient_id'=>$_POST['patient_id'],
                            'doctor_id'=>$_POST['doctor_id'],
                            'month'=>$_POST['month'],
                            'insurance'=>$_POST['insurance'],
                            'cpt_code'=>$_POST['cpt_code'],
                            'description'=>$_POST['description'],
                            'quantity'=>$_POST['quantity'],
                            'rate'=>$_POST['rate'],
                            'balance'=>$_POST['balance'],
                            'total_invoice'=>$_POST['total_invoice'],
                            'updateOn'=>date('Y-m-d H:i:s'),
                           );
              
             $st =  $this->Claim_model->update(array('id'=>$cid),$claimData);
            if($st){
                  $this->session->set_flashdata('success', 'Claim update successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('claim/viewclaim/'.$cid);
             }
            $template['claimdata'] = $this->array_flatten($this->Claim_model->getResult(array('*'),array('id'=>$id)));
            $template['bypatient'] = $this->array_flatten($this->Payment_model->getResult(array('SUM(amount) as pamt'),array('paid_by'=>'patient','claim_id'=>$id)));
            $template['byclaim'] = $this->array_flatten($this->Payment_model->getResult(array('SUM(amount) as camt'),array('paid_by'=>'claim','claim_id'=>$id)));
             $template['doctors'] = $this->Doctors_model->getResult(array('*'));
            $template['patients'] = $this->Patient_model->getResult(array('id','fname','lname','mname'));
            $template['insurance'] = $this->Insurance_model->getResult(array('*'));
            $template['cpts'] = $this->Cptcode_model->getResult(array('*'));
            $template['title']='Insurance Claim';
            $template['subtitle']='Edit-Claim';
            $template['theme']='theme/claim';
            $template['ancher']='claim';
            if($this->CI->checkPermission('cl_2')){ 
              $template['page']='claim/edit';
            }else{
              $template['page']='access/index';
            }
            $this->load->view('template',$template);
  }


  public function viewclaim($id){

          $join=array('patients'=>'patients.id=claims.patient_id',
                        'insurance'=>'insurance.id=claims.insurance',
                        'cptcode'=>'cptcode.id=claims.cpt_code'
                      );
            $claims = $this->Claim_model->getResult(array('tbl_patients.fname as pfname','tbl_patients.lname as plname','insurance.name AS insurancename','cptcode.code as code','claims.*'),array('claims.id'=>$id),$join);
            $template['claimdata']=$this->array_flatten($claims);
            $template['title']='Insurance Claim';
            $template['subtitle']='View Claim';
            $template['theme']='theme/claim';
            $template['ancher']='claim';
            if($this->CI->checkPermission('cl_4')){ 
              $template['page']='claim/view';
            }else{
              $template['page']='access/index';
            } 
             
           $this->load->view('template',$template);
  }

  public function addpayment()
  {
        if(isset($_POST['save'])){
             $payData = array(
                  'claim_id'=>$_POST['claim_id'],
                  'amount'=>$_POST['amount'],
                  'paid_by'=>$_POST['paid_by'],
                  'date_time'=>date('Y-m-d H:i:s'),
                  'rc_by'=>$this->login['id']
                );
              $pid =$this->Payment_model->insert($payData);
              if($pid>0){
                $rec = floatval($_POST['amount'])+floatval($_POST['total_rec']);
                $bal = floatval($_POST['total_invoice'])-floatval($rec);
                $data=array('balance'=>$bal);
                $log= $this->Claim_model->update(array('id'=>$_POST['claim_id']),$data);
                 $this->session->set_flashdata('success', 'Payment  Added successfully');
             }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('claim/viewclaim/'.$_POST['claim_id']);
            }
             
  }
  public function updateBulkstatus(){
      //print_r($_POST);
      $bulkid = $_POST['ids'];
      $st = $_POST['action'];
       foreach ($bulkid as $key => $value) {
           $log= $this->Claim_model->update(array('id'=>$value),array('status'=>$st));
       }
       echo "success";
  }

  public function changestatus(){
           $log= $this->Claim_model->update(array('id'=>$_POST['id']),array('status'=>$_POST['st']));
           if($log){
               if($_POST['st']==1){
                  $this->session->set_flashdata('success', 'claim Approved successfully');
                }else if($_POST['st']==2){
                  $this->session->set_flashdata('success', 'claim Resubmitted successfully');
                }
                 $result=array('status'=>'success');
             }else{
                 $result=array('status'=>'error');
                 $this->session->set_flashdata('error', 'internal error !');
             }
        echo json_encode($result);
    }

    public function delete($id){
      if($this->CI->checkPermission('cl_3')){     
           $delete = $this->Claim_model->delete(array('id'=>$id));
           if($delete){
                $this->session->set_flashdata('success', 'Claim deleted successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('claim');
        
      }else{
        $this->session->set_flashdata('error', 'You dont have access');
            redirect('claim');
      }
        
    } 

    public function import() {     
           
              $template['title']='Claim';
              $template['subtitle']='Import-Claim';
              $template['theme']='theme/claim';
              $template['ancher']='cliam';
            if($this->CI->checkPermission('cl_1')){ 
              $template['page']='claim/import'; 
            }else{
              $template['page']='access/index';
            }

              $this->load->view('template',$template);
       }

       public  function ImportExcel() {  
         //Path of files were you want to upload on localhost (C:/xampp/htdocs/ProjectName/uploads/excel/)  
         $configUpload['upload_path'] = FCPATH.'assets/uploads/claimexcel/';
         $configUpload['allowed_types'] = 'xls|xlsx|csv';
         $configUpload['max_size'] = '5000';
         $this->load->library('upload', $configUpload);
         $this->upload->do_upload('chooseFile');  
         $upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
         $file_name = $upload_data['file_name']; //uploded file name
         $extension=$upload_data['file_ext'];    // uploded file extension
         ini_set('memory_limit', '-1');
         ini_set('memory_limit', '2G');
         PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
         //$objReader =PHPExcel_IOFactory::createReader('Excel5');     //For excel 2003 
         $objReader= PHPExcel_IOFactory::createReader('Excel2007'); // For excel 2007     
              //Set to read only
         $objReader->setReadDataOnly(true);       
        //Load excel file
         $objPHPExcel=$objReader->load(FCPATH.'assets/uploads/claimexcel/'.$file_name);    
         $totalrows=$objPHPExcel->setActiveSheetIndex(0)->getHighestRow();   //Count Numbe of rows avalable in excel         
         $objWorksheet=$objPHPExcel->setActiveSheetIndex(0);                
          //loop from first data untill last data  
         $n=1;
          for($i=3;$i<=$totalrows;$i++)
          {
             $claimData=array();
            $pname=$objWorksheet->getCellByColumnAndRow(2,$i)->getValue();
            $like='';$whr="";
            if($pname!=''){
            $pnameArr = explode(' ', $pname);
              $first = reset($pnameArr); $last = end($pnameArr);
              $like ="(`fname` LIKE '%".$first."%' AND `lname` LIKE '%".$last."%')";
            }
            $pcontact=$objWorksheet->getCellByColumnAndRow(3,$i)->getValue();
               $pdob=$objWorksheet->getCellByColumnAndRow(4,$i)->getValue();
             if($pdob!=''){
              $acArr = explode('/', $pdob);
              if(count($acArr)!=3){
                  $pdob = date('m/d/Y',PHPExcel_Shared_Date::ExcelToPHP($objWorksheet->getCellByColumnAndRow(4, $i)->getValue()));  // array index 1
              }
             
               $dob = $this->createFormatDate($pdob,'m/d/Y','Y-m-d');
               $whr= "`dob`='".$dob."'";
             }

             if($pcontact!=''){
               if($whr!=''){ $whr .= " OR `mobile`='".$pcontact."'";}else{$whr = "`mobile`='".$pcontact."'";}   
             }
             $where ='';
             if($whr!='' ){ $where .=$whr; }
             if($like!=''){ if($whr!=''){ $where .=" OR ".$like;}else{ $where .=$like; }}
             $wheres =" WHERE ".$where;
             $pdata = $this->db->query("SELECT * FROM `tbl_patients` ".$wheres." ORDER BY id ASC LIMIT 1")->result_array();
             if(count($pdata)>0){ $claimData['patient_id']=$pdata[0]['id']; }
             $providername = $objWorksheet->getCellByColumnAndRow(0,$i)->getValue();
             $prodata = $this->db->query("SELECT * FROM `tbl_doctors` WHERE `name` LIKE '%".$providername."%' ORDER BY id ASC LIMIT 1")->result_array();
             if(count($prodata)>0){ $claimData['doctor_id'] = $prodata[0]['id']; }
             $claimData['cpt_code'] = $objWorksheet->getCellByColumnAndRow(5,$i)->getValue();
             $balance = $objWorksheet->getCellByColumnAndRow(7,$i)->getValue();
             $balance = preg_replace('/[^a-zA-Z0-9-_\.]/','', $balance);
             $claimData['balance'] = $balance;
             $claimData['transaction_type'] = "claim";
               $claimData['addedOn'] = date('Y-m-d H:i:s');
                 $claimData['updateOn'] = date('Y-m-d H:i:s');
            if(isset($claimData['patient_id']) && isset($claimData['doctor_id'])){
               // print_r($claimData);
               // echo "<hr/><br/>";
                 $this->Claim_model->insert($claimData);
                 $n++;
             }
            
          }
             unlink(FCPATH.'assets/uploads/claimexcel/'.$file_name); //File Deleted After uploading in database .       
             $this->session->set_flashdata('success', $n.' Patient  Added Successfully');
             redirect('claim/');
     }

       public  function downloadfile($path){
        $this->load->helper('download');
        $filename = "sample_claim.xlsx";
       if($filename!=''){
          if(file_exists(FCPATH."assets/uploads/sample/".$filename)){
            $data = file_get_contents(base_url("assets/uploads/sample/".$filename)); // Read the file's contents
            $name = $filename;
            force_download($name, $data);
            $this->session->set_flashdata('success', 'Download successfully');
          }else{
           $this->session->set_flashdata('error', 'File not exist');
          }
       }else{
          $this->session->set_flashdata('error', 'Invalid file name');
       }
       redirect('claim/import');
    }
        
        
	    public function popup($page_name = '' , $param2 = '',$param3 = '' ){
           $page_data['param2']    = $param2;
           $page_data['param3']    = $param3;
           $this->load->view('claim/'.$page_name ,$page_data);
        }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Team extends MY_Controller {

	public function __construct()
	{
      parent::__construct();
        if($this->CI->checkPermission('tm')){
           }else{
             $this->session->set_flashdata('error', 'please login to access your account');
              redirect('login');
            }
      $this->load->model(array('Module_model','User_model','Cities_model','States_model','Countries_model'));

  }
    
	public function index()
	{   $join=array('states'=>'states.id=user.state_id','cities'=>'cities.id=user.city_id');
      $template['users'] = $this->User_model->getResult(array('states.name AS state','cities.name AS city','user.*'),'',$join);
      $template['title']='Team Member';
      $template['subtitle']='List-Member';
      $template['theme']='theme/team';
      $template['ancher']='team';
      
      if($this->CI->checkPermission('tm_4')){ 
        $template['page']='team/list';
      }else{
        $template['page']='access/index';
      } 
      $this->load->view('template',$template);
	}
  public function add()
  {   

    if(isset($_POST['save'])){
         $password = $this->getRandomChar(10,6);
         $_POST['userID'] = $this->getRandom(2,8);
         $_POST['password']=md5($password);
         $_POST['type']='user';
         $_POST['addedOn']=date('Y-m-d H:i:s');
         $_POST['updateOn']=date('Y-m-d H:i:s');
         $_POST['profile']="assets/profile/face.png";
         $_POST['dob']=$this->createFormatDate($_POST['dob'],'m/d/Y','Y-m-d');
         $modules = $this->Module_model->getResult(array('*'),array('is_parent'=>1));
         $parmessions = array();
         foreach ($modules as $row) {
            if(isset($_POST[$row['code']])){
              array_push($parmessions, $row['code']);
              unset($_POST[$row['code']]);
           $childs = $this->Module_model->getResult(array('*'),array('parent_id'=>$row['id']));
             foreach ($childs as $ch) {
                 if(isset($_POST[$ch['code']])){
                     array_push($parmessions, $ch['code']);
                     unset($_POST[$ch['code']]);
                   }
             }
           }
         }
         if(count($parmessions)>0){
          $_POST['access'] = implode(',',$parmessions);
         }else{
           $_POST['access'] ='';
         }
         unset($_POST['save']);
        $uid = $this->User_model->insert($_POST);
        if($uid>0){
          $this->SendMail($uid,$password);
          $this->session->set_flashdata('success', 'User Added successfully');
        }else{
          $this->session->set_flashdata('error', 'internal error !');
        }
        redirect('team');
     }
      $template['states']=$this->States_model->getResult(array('*'),array('country_id'=>'231'));  
      $template['modules']=$this->Module_model->getResult(array('*'),array('is_parent'=>1));     
      $template['title']='Team Member';
      $template['subtitle']='Add-Member';
      $template['theme']='theme/team';
      $template['ancher']='team';
     if($this->CI->checkPermission('tm_1')){ 
        $template['page']='team/add';
      }else{
        $template['page']='access/index';
      } 
      $this->load->view('template',$template);
  }

  public function edit($id)
  {   
    if(isset($_POST['save'])){
         $ids = $_POST['id'];
         $_POST['updateOn']=date('Y-m-d H:i:s');
        $_POST['dob']=$this->createFormatDate($_POST['dob'],'m/d/Y','Y-m-d');
         $modules = $this->Module_model->getResult(array('*'),array('is_parent'=>1));
         $parmessions = array();
         foreach ($modules as $row) {
            if(isset($_POST[$row['code']])){
              array_push($parmessions, $row['code']);
              unset($_POST[$row['code']]);
           $childs = $this->Module_model->getResult(array('*'),array('parent_id'=>$row['id']));
             foreach ($childs as $ch) {
                 if(isset($_POST[$ch['code']])){
                     array_push($parmessions, $ch['code']);
                     unset($_POST[$ch['code']]);
                   }
             }
           }
         }
         if(count($parmessions)>0){
          $_POST['access'] = implode(',',$parmessions);
         }else{
           $_POST['access'] ='';
         }
        unset($_POST['save']);
        unset($_POST['id']);
        $update = $this->User_model->update(array('id'=>$ids),$_POST);
        if($update){
          $this->session->set_flashdata('success', 'User update successfully');
        }else{
          $this->session->set_flashdata('error', 'internal error !');
        }
        redirect('team');
     }
      $userdata=$this->array_flatten($this->User_model->getResult(array('*'),array('id'=>$id)));
      $template['userdata']=  $userdata;
      $template['states']=$this->States_model->getResult(array('*'),array('country_id'=>'231'));
      $template['cities']=$this->Cities_model->getResult(array('*'),array('state_id'=>$userdata['state_id']));  
      $template['modules']=$this->Module_model->getResult(array('*'),array('is_parent'=>1));     
      $template['title']='Team Member';
      $template['subtitle']='Update-Member';
      $template['theme']='theme/team';
      $template['ancher']='team';
      if($this->CI->checkPermission('tm_2')){ 
        $template['page']='team/edit';
      }else{
        $template['page']='access/index';
      } 
      $this->load->view('template',$template);
  }

  public function changestatus(){
           $log= $this->User_model->update(array('id'=>$_POST['id']),array('status'=>$_POST['st']));
           if($log){
                 $this->session->set_flashdata('success', 'status change successfully');
                 $result=array('status'=>'success');
             }else{
                 $result=array('status'=>'error');
                 $this->session->set_flashdata('error', 'internal error !');
             }
        echo json_encode($result);
    }

    public function delete($id){
        if($this->CI->checkPermission('tm_3')){
           $delete = $this->User_model->delete(array('id'=>$id));
            if($delete){
                $this->session->set_flashdata('success', 'User deleted successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('team');
            }else{
               $this->session->set_flashdata('error', 'You dont have access');
                redirect('team');   
            }
       }

  public function SendMail($uid,$pass){
      $array = $this->User_model->getResult(array('*'),array('id'=>$uid));
       $row = $this->array_flatten($array);
        $config = Array(
                          'protocol' => 'sendmail',
                          'mailtype' => 'html', 
                          'charset' => 'utf-8',
                          'wordwrap' => TRUE
                        );

         $from_email = "praveen@redboxx.in"; 
         $to_email =$row['email']; 
         //Load email library 
         $this->load->library('email'); 
         $this->email->initialize($config);
         $this->email->set_newline("\r\n");
         $this->email->clear(TRUE);
         $this->email->from($from_email, 'Medicare Claim'); 
         $this->email->to($to_email);
         $this->email->subject('Welcome to Madicare Claim'); 
          
           $htmlContent  = "<p>Dear ".$row['fname']." ".$row['lname'].",</p></br>";
           $htmlContent .= "<p>Welcome to Medicare Claim account</p></br>";
           $htmlContent .= "<p>Thank you for being with us! Your  account has now been setup and this email contains all the information you will need  to login your account.</p></br>";

           $htmlContent .= "<h2 style='color:#10c7d6'> Account Login credential.</h2></br>";
           $htmlContent .= "<p>Please use below credential  to login  the Medicare Claim account .<p></br>";
           $htmlContent .= "<p>UserID :- ".$row['userID']."<p></br>";
           $htmlContent .= "<p>Username :- ".$row['username']."<p></br>";
           $htmlContent .= "<p>Password :- <b>".$pass."</b></p></br>";
           //$htmlContent .= "<p>Please change password after getting login.</p></br>";
           $htmlContent .= "<p>To visit your account click the following link:</p></br>"; 
           $htmlContent .= "<a href='".base_url()."login'>Click here to login now.</a></br>"; 
            $htmlContent .= "<p> Have a great day!</p></br>";
           
          
           $htmlContent .= "<p>Thanks,</p>";
           $htmlContent .= "<p>Medicare Claim Team</p>";
          $this->email->message($htmlContent); 
   
         //Send mail 
         $this->email->send();
         
    } 
        
 public function popup($page_name = '' , $param2 = '',$param3 = '' ){
     $page_data['param2']    = $param2;
     $page_data['param3']    = $param3;
     $this->load->view('team/'.$page_name ,$page_data);
 }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Doctors extends MY_Controller {

	public function __construct()
	{
          parent::__construct();
           if($this->CI->checkPermission('dr')){ 
             }else{
               $this->session->set_flashdata('error', 'please login to access your account');
               redirect('login');
            }
         $this->load->model(array('Doctors_model'));
  }
    
    	public function index()
    	{   
          if(isset($_POST['save'])){ 
               unset($_POST['save']);
               $id = $this->Doctors_model->insert($_POST);
              if($id>0){
                $this->session->set_flashdata('success', 'Doctor added successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('doctors');
            }
          $template['doctors']=$this->Doctors_model->getResult(array('*'));  
          $template['title']='Doctors';
          $template['subtitle']='Add & view doctors';
          $template['theme']='theme/doctors';
          $template['ancher']='doctors';
            
          if($this->CI->checkPermission('inc_4')){ 
             $template['page']='doctors/doctors';
            }else{
              $template['page']='access/index';
            } 
    	    $this->load->view('template',$template);
    	}

      public function edit($id) { 
        if($this->CI->checkPermission('dr_2')){     
            if(isset($_POST['save'])){
               $ids= $_POST['id'];
               $data =array('name'=>$_POST['ename'],);
                $update = $this->Doctors_model->update(array('id'=>$ids),$data);
              if($update){
                $this->session->set_flashdata('success', 'Data updated successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('doctors');
            }
          }else{
            $this->session->set_flashdata('error', 'You dont have access');
            redirect('doctors');
          }
       }
        public function delete($id){
          if($this->CI->checkPermission('dr_3')){  
           $delete = $this->Doctors_model->delete(array('id'=>$id));
           if($delete){
                $this->session->set_flashdata('success', 'deleted successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('doctors');
            }else{
              $this->session->set_flashdata('error', 'You dont have access');
              redirect('doctors');   
            }
        }
        
        
	    public function popup($page_name = '' , $param2 = '',$param3 = '' ){
           $page_data['param2']    = $param2;
           $page_data['param3']    = $param3;
           $this->load->view('doctors/'.$page_name ,$page_data);
        }
}

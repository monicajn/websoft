<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patient extends MY_Controller {

	public function __construct()
	{
          parent::__construct();
          if($this->CI->checkPermission('pt')){  
             }else{
               $this->session->set_flashdata('error', 'please login to access your account');
               redirect('login');
            }
           $this->load->library('PHPExcel');
         $this->load->model(array('Patient_model','Cities_model','States_model','Countries_model','Insurance_model','Cities_model'));
  }
    
    	public function index()
    	{     
         $join=array('states'=>'states.id=patients.state_id','cities'=>'cities.id=patients.city_id');
          $template['patients'] = $this->Patient_model->getResult(array('states.name AS state','cities.name AS city','patients.*'),'',$join);
          $template['title']='Patient';
          $template['subtitle']='List-Patient';
          $template['theme']='theme/patient';
          $template['ancher']='patient';
          if($this->CI->checkPermission('pt_4')){ 
            $template['page']='patient/list'; 
          }else{
            $template['page']='access/index';
          }          
    	    $this->load->view('template',$template);
    	}
        public function add() {     
           
              $template['insurance'] = $this->Insurance_model->getResult(array('*'));
              $template['states']=$this->States_model->getResult(array('*'),array('country_id'=>'231'));       
              $template['title']='Patient';
              $template['subtitle']='Add-Patient';
              $template['theme']='theme/patient';
              $template['ancher']='patient';
            if($this->CI->checkPermission('pt_1')){ 
              $template['page']='patient/add'; 
            }else{
              $template['page']='access/index';
            }

              $this->load->view('template',$template);
       }

       public function import() {     
           
              $template['title']='Patient';
              $template['subtitle']='Import-Patient';
              $template['theme']='theme/patient';
              $template['ancher']='patient';
            if($this->CI->checkPermission('pt_1')){ 
              $template['page']='patient/import'; 
            }else{
              $template['page']='access/index';
            }

              $this->load->view('template',$template);
       }

       public  function savedata ()
       {
           $_POST['dob']=$this->createFormatDate($_POST['dob'],'m/d/Y','Y-m-d');
           $chk = $this->checkPatientExist($_POST['fname'],$_POST['lname'],$_POST['dob']);
         if($chk){
               if(isset($_POST['sex']) && $_POST['sex']!=''){ $_POST['sex'] = trim($_POST['sex']);}
                if(isset($_POST['pregnant']) && $_POST['pregnant']!=''){ $_POST['pregnant'] = trim($_POST['pregnant']);}
               $_POST['patientID'] = $this->getRandom(2,8);
               $_POST['addedOn']=date('Y-m-d H:i:s');
               $_POST['updateOn']=date('Y-m-d H:i:s');
               unset($_POST['save']);
               $uid = $this->Patient_model->insert($_POST);
              if($uid>0){
                $this->session->set_flashdata('success', 'Patient Added successfully');
                echo "success";
              }else{
                $this->session->set_flashdata('error', 'internal error !');
                echo "error";
              }
              
            }else{
              echo "false";
            }
       }

       public  function updatedata ()
       {
           $dob=$this->createFormatDate($_POST['dob'],'m/d/Y','Y-m-d');
           $chk = $this->checkPatientExist($_POST['fname'],$_POST['lname'],$dob,$_POST['id']);
         if($chk){
                $_POST['updateOn']=date('Y-m-d H:i:s');
                $_POST['dob']=$dob;
                $ids= $_POST['id'];
                unset($_POST['save']);
               $update = $this->Patient_model->update(array('id'=>$ids),$_POST);;
              if($update){
                $this->session->set_flashdata('success', 'Patient update successfully');
                echo "success";
              }else{
                $this->session->set_flashdata('error', 'internal error !');
                echo "error";
              }
              
            }else{
              echo "false";
            }
       }

        public  function updatedataimport()
       {   
          $counter = $_POST['counter'];$p=0;
          for($i=1; $i<$counter;$i++){
           if(isset($_POST['chk_'.$i]) && $_POST['pid'.$i]!=0){
                 $dob='';if(isset($_POST['dob'.$i]) && $_POST['dob'.$i]!==''){ $dob=$this->createFormatDate($_POST['dob'.$i],'m/d/Y','Y-m-d'); }
                $updateData = array(
                      'updateOn' => date('Y-m-d H:i:s'),
                      'dob'      => $dob,
                      'fname'    =>$_POST['fname'.$i],
                      'mname'    =>$_POST['mname'.$i],
                      'lname'    =>$_POST['lname'.$i],
                      'email'    =>$_POST['email'.$i],
                      'mobile'   =>$_POST['mobile'.$i],
                      'address'  =>$_POST['address'.$i],
                      'pregnant' =>$_POST['pregnant'.$i],
                      'sex'      =>$_POST['sex'.$i],
                      'insurance_member_id'=>$_POST['insurance_member_id'.$i],
                      'insurance_company'=>$_POST['insurance_company'.$i],
                      'state_id' =>$_POST['state_id'.$i],
                      'city_id'  =>$_POST['city_id'.$i],
                      'zipcode'  =>$_POST['zipcode'.$i],
                  );
               
                $ids= $_POST['pid'.$i ];
                print_r($updateData);
                $update = $this->Patient_model->update(array('id'=>$ids),$updateData);;
                $p++;
            }
          }
          $this->session->set_flashdata('success', $p.' Patient update successfully');       
          redirect('patient/');
            
       }


       public function edit($id) {     
            
            $patientdata = $this->array_flatten($this->Patient_model->getResult(array('*'),array('id'=>$id)));
             $template['patientdata']=  $patientdata;
            $template['insurance'] = $this->Insurance_model->getResult(array('*'));
            $template['states']=$this->States_model->getResult(array('*'),array('country_id'=>'231')); 
            $template['cities']=$this->Cities_model->getResult(array('*'),array('state_id'=>$patientdata['state_id']));       
            $template['title']='Patient';
            $template['subtitle']='edit-Patient';
            $template['theme']='theme/patient';
            $template['ancher']='patient';
           
             if($this->CI->checkPermission('pt_2')){ 
              $template['page']='patient/edit'; 
            }else{
              $template['page']='access/index'; 
            } 
           $this->load->view('template',$template);
       }

       public function delete($id){
        if($this->CI->checkPermission('pt_3')){ 
           $delete = $this->Patient_model->delete(array('id'=>$id));
            if($delete){
                $this->session->set_flashdata('success', 'Patient deleted successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('patient');
          }else{
            $this->session->set_flashdata('error', 'You dont have permission to access');
            redirect('patient');
          }
       }

    public function checkPatientExist($fname,$lname,$dob,$id=''){  
            $whr = array('LOWER(fname)'=>strtolower($fname),'LOWER(lname)'=>strtolower($lname),'DATE(dob)'=>$dob );
             if($id!=''){
              $whr['id!=']=$id;
             }
            $data = $this->Patient_model->getResult(array('id'),$whr);
             if(count($data)>0){
               return false;

            }else{
               return true;
             }
    }

    public function checkPatientExistimport(){ 
             $fname= $_POST['fname'];
             $lname=$_POST['lname'];
             $mobile=$_POST['mobile'];
            $whr = array('LOWER(fname)'=>strtolower($fname),'LOWER(lname)'=>strtolower($lname),'mobile'=>$mobile);
            $data = $this->Patient_model->getResult(array('id'),$whr);
          
             if(count($data)>0){
                 $result=array('status'=>'error','pid'=>$data[0]['id']);
             }else{
                $result=array('status'=>'success','pid' =>0);
             }

            echo json_encode($result);
    }

    

     public  function patientAction()
     {
      $action  = $_POST['action'];
      if($action=='delete'){
         $bulkids = $_POST['pids'];
           foreach ($bulkids as $key => $value) {
           $log= $this->Patient_model->delete(array('id'=>$value));
          }
      }
       $this->session->set_flashdata('success', 'Patient deleted successfully');
     }

     public  function downloadfile(){
       $this->load->helper('download');
       $filename = "sample_patient.xlsx";
       if($filename!=''){
          if(file_exists(FCPATH."assets/uploads/sample/".$filename)){
            $data = file_get_contents(base_url("assets/uploads/sample/".$filename)); // Read the file's contents
            $name = $filename;
            force_download($name, $data);
            $this->session->set_flashdata('success', 'Download successfully');
          }else{
           $this->session->set_flashdata('error', 'File not exist');
          }
       }else{
          $this->session->set_flashdata('error', 'Invalid file name');
       }
       redirect('patient/import');
    }

    public  function importexcelfile(){
         $configUpload['upload_path'] = FCPATH.'assets/uploads/patientexcel/';
         $configUpload['allowed_types'] = 'xls|xlsx|csv';
         $configUpload['max_size'] = '5000';
         $this->load->library('upload', $configUpload);
         $this->upload->do_upload('chooseFile');  
         $upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
         $file_name = $upload_data['file_name']; //uploded file name
         $extension=$upload_data['file_ext'];    // uploded file extension
         ini_set('memory_limit', '-1');
         ini_set('memory_limit', '2G');
         PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
         $objReader= PHPExcel_IOFactory::createReader('Excel2007'); // For excel 2007     
              //Set to read only
         $objReader->setReadDataOnly(true);       
        //Load excel file
        $objPHPExcel=$objReader->load(FCPATH.'assets/uploads/patientexcel/'.$file_name);    
         $totalrows=$objPHPExcel->setActiveSheetIndex(0)->getHighestRow();   //Count Numbe of rows avalable in excel         
         $objWorksheet=$objPHPExcel->setActiveSheetIndex(0);                
          //loop from first data untill last data  
         $n=1;
          $json_array=array();
          for($i=3;$i<=$totalrows;$i++)
          {
            if($objWorksheet->getCellByColumnAndRow(1,$i)->getValue()!=''){
                $data_array=array();
                  $patientdata['fname']=$objWorksheet->getCellByColumnAndRow(1,$i)->getValue();
                  $patientdata['mname']=$objWorksheet->getCellByColumnAndRow(2,$i)->getValue();
                  $patientdata['lname']=$objWorksheet->getCellByColumnAndRow(3,$i)->getValue();
                  $patientdata['insurance_member_id']=$objWorksheet->getCellByColumnAndRow(4,$i)->getValue();
                  $patientdata['email']=$objWorksheet->getCellByColumnAndRow(5,$i)->getValue();
                  $patientdata['address']=$objWorksheet->getCellByColumnAndRow(6,$i)->getValue();

                  $state = $objWorksheet->getCellByColumnAndRow(7,$i)->getValue();
                  $stdata = $this->db->query("SELECT * FROM `tbl_states` WHERE name LIKE '%".$state."%' ORDER BY name ASC LIMIT 1")->result_array();
                  if(count($stdata)>0){  $patientdata['state_id']=$stdata[0]['id']; }else{ $patientdata['state_id']='';}

                  $city = $objWorksheet->getCellByColumnAndRow(8,$i)->getValue();
                  $ctdata = $this->db->query("SELECT * FROM `tbl_cities` WHERE name LIKE '%".$city."%' ORDER BY name ASC LIMIT 1")->result_array();
                  if(count($ctdata)>0){  $patientdata['city_id']=$ctdata[0]['id']; }else{ $patientdata['city_id']='';}

                  $patientdata['zipcode']=$objWorksheet->getCellByColumnAndRow(9,$i)->getValue();
                  $patientdata['mobile']=$objWorksheet->getCellByColumnAndRow(10,$i)->getValue();
                  $provider=$objWorksheet->getCellByColumnAndRow(11,$i)->getValue();
                  $com = $this->db->query("SELECT * FROM `tbl_insurance` WHERE name LIKE '%".$provider."%' ORDER BY name ASC LIMIT 1")->result_array();
                  if(count($com)>0){  $patientdata['insurance_company']=$com[0]['id']; }else{ $patientdata['insurance_company']='';}
                  $s_sex =$objWorksheet->getCellByColumnAndRow(12,$i)->getValue();
                  $len = strlen($s_sex);
                  if($len>1){ $a=$len-1; $s_sex =  substr($s_sex,0,-$a);}else{ $s_sex= $s_sex;}
                  $patientdata['sex']=$s_sex;

                   $s_pregnant =$objWorksheet->getCellByColumnAndRow(13,$i)->getValue();
                    $line = trim($s_pregnant," \t");
                   $line = str_replace("\r","",$line); 
                   $patientdata['pregnant']=rtrim(trim(str_replace('\r','',$line)));

                    //$this->Patient_model->insert($patientdata);
                    $n++; 
                   array_push($json_array, $patientdata);
                        
            }   
          }
          unlink(FCPATH.'assets/uploads/patientexcel/'.$file_name); //File Deleted After uploading in database .
          echo json_encode($json_array);

    }
   
	    public function popup($page_name = '' , $param2 = '',$param3 = '' ){
           $page_data['param2']    = $param2;
           $page_data['param3']    = $param3;
           $this->load->view('patient/'.$page_name ,$page_data);
        }
}

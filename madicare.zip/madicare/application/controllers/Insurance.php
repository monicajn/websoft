<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Insurance extends MY_Controller {

	public function __construct()
	{
          parent::__construct();
           if($this->CI->checkPermission('inc')){ 
             }else{
               $this->session->set_flashdata('error', 'please login to access your account');
               redirect('login');
            }
         $this->load->model(array('Insurance_model'));
  }
    
    	public function index()
    	{   
          if(isset($_POST['save'])){ 
               unset($_POST['save']);
               $id = $this->Insurance_model->insert($_POST);
              if($id>0){
                $this->session->set_flashdata('success', 'Insurance Company added successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('insurance');
            }
          $template['insurance']=$this->Insurance_model->getResult(array('*'));  
          $template['title']='Insurance Comapny';
          $template['subtitle']='add & view Insurance Comapny';
          $template['theme']='theme/insurance';
          $template['ancher']='insurance';
            
          if($this->CI->checkPermission('inc_4')){ 
             $template['page']='insurance/insurance';
            }else{
              $template['page']='access/index';
            } 
    	    $this->load->view('template',$template);
    	}

      public function edit($id) { 
        if($this->CI->checkPermission('inc_2')){     
            if(isset($_POST['save'])){
               $ids= $_POST['id'];
               $data =array('name'=>$_POST['ename'],);
                $update = $this->Insurance_model->update(array('id'=>$ids),$data);
              if($update){
                $this->session->set_flashdata('success', 'Data updated successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('insurance');
            }
          }else{
            $this->session->set_flashdata('error', 'You dont have access');
            redirect('insurance');
          }
       }
        public function delete($id){
          if($this->CI->checkPermission('inc_3')){  
           $delete = $this->Insurance_model->delete(array('id'=>$id));
           if($delete){
                $this->session->set_flashdata('success', 'deleted successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('insurance');
            }else{
              $this->session->set_flashdata('error', 'You dont have access');
              redirect('insurance');   
            }
        }
        
        
	    public function popup($page_name = '' , $param2 = '',$param3 = '' ){
           $page_data['param2']    = $param2;
           $page_data['param3']    = $param3;
           $this->load->view('insurance/'.$page_name ,$page_data);
        }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MY_Controller {

	public function __construct(){
	         parent::__construct();
           $this->load->model(array('Insurance_model','Claim_model'));
   }
    
	public function index()
	{        $template['insurance'] = $this->Insurance_model->getResult();
                  $joinclaim=array('patients'=>'patients.id=claims.patient_id',
                        'insurance'=>'insurance.id=claims.insurance',
                        'cptcode'=>'cptcode.id=claims.cpt_code'
                      );
             $selectcl =  array('CONCAT(tbl_patients.fname, " ", tbl_patients.mname, " " , tbl_patients.lname) as patientname',
                                 'insurance.name AS insurancename','cptcode.code as code','claims.*');
           $template['claimesbydate'] = $this->Claim_model->getResult($selectcl,array('DATE(tbl_claims.addedOn)'=>date('Y-m-d')),$joinclaim);
        if($this->session->userdata('type')=='admin'){ 
            $template['title']='Home';
            $template['subtitle']='Dashboard';
            $template['ancher']='home';
            $template['theme']='theme/dashboard';
            $template['page']='home/dashboard';
            $this->load->view('template',$template);
        }else if($this->session->userdata('type')=='user'){
           $template['title']='Home';
           $template['subtitle']='Dashboard';
           $template['ancher']='home';
           $template['theme']='theme/dashboard';
           $template['page']='home/dashboard';
          $this->load->view('template',$template);
             
        }else{
           $this->session->set_flashdata('access', 'invalid user  access');
             redirect('login');
        }
	}
        
         
          
	
	public function logout()
	{ 

		             $this->session->unset_userdata('id');
                 $this->session->unset_userdata('userID');
                $this->session->unset_userdata('name');
                $this->session->unset_userdata('type');
               $this->session->unset_userdata('email');
		$this->session->sess_destroy();
		redirect('login/');
	}
	
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cptcode extends MY_Controller {

	public function __construct()
	{
          parent::__construct();
           if($this->CI->checkPermission('cpt')){
             }else{
               $this->session->set_flashdata('error', 'please login to access your account');
               redirect('login');
            }
         $this->load->model(array('Cptcode_model'));
  }
    
    	public function index()
    	{   
          if(isset($_POST['save'])){
               
               unset($_POST['save']);
               $id = $this->Cptcode_model->insert($_POST);
              if($id>0){
                $this->session->set_flashdata('success', 'CPT code added successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('cptcode');
            }
          $template['cptcodes'] = $this->Cptcode_model->getResult(array('*'));
          $template['title']='CPT code';
          $template['subtitle']='Add & view CPT code';
          $template['theme']='theme/cptcode';
          $template['ancher']='cptcode';
        
          if($this->CI->checkPermission('cpt_4')){ 
              $template['page']='cptcode/cptcode'; 
            }else{
              $template['page']='access/index';
            }            
    	    $this->load->view('template',$template);
    	}
        
       public function edit($id) { 
        if($this->CI->checkPermission('cpt_2')){        
            if(isset($_POST['save'])){
               $ids= $_POST['id'];
               $data =array('code'=>$_POST['ecode'],'rate'=>$_POST['erate'],'description'=>$_POST['edescription']);
                $update = $this->Cptcode_model->update(array('id'=>$ids),$data);
              if($update){
                $this->session->set_flashdata('success', 'CPT code updated successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('cptcode');
            }
          }else{
            $this->session->set_flashdata('error', 'You dont have access');
            redirect('cptcode');
          }
       }

       public function delete($id){
         if($this->CI->checkPermission('cpt_3')){       
            $delete = $this->Cptcode_model->delete(array('id'=>$id));
            if($delete){
                $this->session->set_flashdata('success', 'CPT code deleted successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('cptcode');
            }else{
              $this->session->set_flashdata('error', 'You dont have access');
              redirect('cptcode');
            }
       }
        
     
        
        
	    public function popup($page_name = '' , $param2 = '',$param3 = '' ){
           $page_data['param2']    = $param2;
           $page_data['param3']    = $param3;
           $this->load->view('cptcode/'.$page_name ,$page_data);
        }
}

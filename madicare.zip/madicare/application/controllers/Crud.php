<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends MY_Controller {

	public function __construct()
	{
      parent::__construct();
      $this->load->model(array('Patient_model','Cptcode_model','User_model','Cities_model','States_model','Countries_model'));
  }
    
	  public function getcity()
	   {     
       $state_id = $_POST['state_id'];
       $data = $this->Cities_model->getResult(array('*'),array('state_id'=>$_POST['state_id']));
       $arr=array();
       $data1=array();
        foreach ($data as $row) {
              $arr=array( 'id'=>$row['id'], 'value'=>$row['name']);
              array_push($data1, $arr);
             } 
        echo json_encode($data1);
	  }
    public function addcity($value='')
    {
      $data = array('name'=>$_POST['cityname'],'state_id'=>$_POST['stateid']);
      $cid = $this->Cities_model->insert($data);
       $cities = $this->array_flatten($this->Cities_model->getResult(array('*'),array('id'=>$cid)));
       $arr=array( 'id'=>$cities['id'], 'value'=>$cities['name']);
          echo json_encode($arr);
    }

    public function getcptdata(){     
       $cpt = $_POST['cpt'];
       $_arr = explode('_', $cpt);
       $_data = $this->array_flatten($this->Cptcode_model->getResult(array('*'),array('id'=>$_arr[0])));
       if(count($_data)>0){
        $result = array('status'=>'success','cpt_code'=>$_data['code'],'rate'=>$_data['rate'],'description'=>$_data['description']);
       }else{
        $result = array('status'=>'error','cpt_code'=>'','rate'=>'','description'=>'');
       }
      
        echo json_encode($result);
    }

    

    public function checkUserExist(){
      if(isset($_POST['id'])){
          $whr['id!=']=$_POST['id'];
      }
      if(isset($_POST['username'])){
         $whr['username']=$_POST['username'];
        $data = $this->User_model->getResult(array('id'),$whr);
        if(count($data)>0){
           echo "false";
        }else{
          echo "true";
        }
      }else if(isset($_POST['email'])){
         $whr['email']=$_POST['email'];
        $data = $this->User_model->getResult(array('id'),$whr);
        if(count($data)>0){
           echo "false";
        }else{
          echo "true";
        }
      }else if(isset($_POST['mobile'])){
        $whr['mobile']=$_POST['mobile'];
        $data = $this->User_model->getResult(array('id'),$whr);
        if(count($data)>0){
           echo "false";
        }else{
          echo "true";
        }
      }
    }
    

     public function citypopup($page_name = '' , $param2 = '',$param3 = '' ){
           $page_data['param2']    = $param2;
           $page_data['param3']    = $param3;
           $this->load->view('cities/'.$page_name ,$page_data);
        }

 

//  public  function ImportExcel() {  
// //Path of files were you want to upload on localhost (C:/xampp/htdocs/ProjectName/uploads/excel/)  
//          $configUpload['upload_path'] = FCPATH.'assets/uploads/patientexcel/';
//          $configUpload['allowed_types'] = 'xls|xlsx|csv';
//          $configUpload['max_size'] = '5000';
//          $this->load->library('upload', $configUpload);
//          $this->upload->do_upload('chooseFile');  
//          $upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
//          $file_name = $upload_data['file_name']; //uploded file name
//         $extension=$upload_data['file_ext'];    // uploded file extension
//        ini_set('memory_limit', '-1');
//        ini_set('memory_limit', '2G');
//        PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
//     //$objReader =PHPExcel_IOFactory::createReader('Excel5');     //For excel 2003 
//          $objReader= PHPExcel_IOFactory::createReader('Excel2007'); // For excel 2007     
//               //Set to read only
//          $objReader->setReadDataOnly(true);       
//         //Load excel file
//      $objPHPExcel=$objReader->load(FCPATH.'assets/uploads/patientexcel/'.$file_name);    
//          $totalrows=$objPHPExcel->setActiveSheetIndex(0)->getHighestRow();   //Count Numbe of rows avalable in excel         
//          $objWorksheet=$objPHPExcel->setActiveSheetIndex(0);                
//           //loop from first data untill last data  
//          $n=1;
//           for($i=3;$i<=$totalrows;$i++)
//           {
//             if($objWorksheet->getCellByColumnAndRow(1,$i)->getValue()!=''){
//           $patientdata['patientID'] = $this->getRandom(2,8);
//           $patientdata['fname']=$objWorksheet->getCellByColumnAndRow(1,$i)->getValue();
//           $patientdata['mname']=$objWorksheet->getCellByColumnAndRow(2,$i)->getValue();
//           $patientdata['lname']=$objWorksheet->getCellByColumnAndRow(3,$i)->getValue();
//           $patientdata['insurance_member_id']=$objWorksheet->getCellByColumnAndRow(4,$i)->getValue();
//           $patientdata['email']=$objWorksheet->getCellByColumnAndRow(5,$i)->getValue();
//           $patientdata['address']=$objWorksheet->getCellByColumnAndRow(6,$i)->getValue();
//           $patientdata['mobile']=$objWorksheet->getCellByColumnAndRow(7,$i)->getValue();
//           $provider=$objWorksheet->getCellByColumnAndRow(8,$i)->getValue();
//           $com = $this->db->query("SELECT * FROM `tbl_insurance` WHERE name LIKE '%".$provider."%' ORDER BY name ASC LIMIT 1")->result_array();
//           if(count($com)>0){  $patientdata['insurance_company']=$com[0]['id']; }else{ $patientdata['insurance_company']='';}
//           $s_sex =$objWorksheet->getCellByColumnAndRow(9,$i)->getValue();
//           $len = strlen($s_sex);
//           if($len>1){ $a=$len-1; $s_sex =  substr($s_sex,0,-$a);}else{ $s_sex= $s_sex;}
//           $patientdata['sex']=$s_sex;

//            $s_pregnant =$objWorksheet->getCellByColumnAndRow(10,$i)->getValue();
//             $line = trim($s_pregnant," \t");
//            $line = str_replace("\r","",$line); 
//            $patientdata['pregnant']=rtrim(trim(str_replace('\r','',$line)));

//             $this->Patient_model->insert($patientdata);
//             $n++;      
//             }   
//           }
//              unlink(FCPATH.'assets/uploads/patientexcel/'.$file_name); //File Deleted After uploading in database .       
//                $this->session->set_flashdata('success', $n.' Patient  Added Successfully');
//              redirect('patient/');
//      }
 
}

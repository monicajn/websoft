<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//print_r( debug_backtrace() );
//ini_set('memory_limit', '-1');
//ini_set('max_execution_time', 3000);

class Cities extends MY_Controller {

	public function __construct()
	{
          parent::__construct();
            if($this->CI->checkPermission('ct')){
             }else{
               $this->session->set_flashdata('error', 'please login to access your account');
               redirect('login');
            }
         $this->load->model(array('Cities_model','States_model'));
  }
    
    	public function index()
    	{   
          if(isset($_POST['save'])){
               
               unset($_POST['save']);
               $id = $this->Cities_model->insert($_POST);
              if($id>0){
                $this->session->set_flashdata('success', 'City added successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('cities');
            }
          $join=array('states'=>'states.id=cities.state_id');
          $template['cities']=$this->Cities_model->getResult(array('cities.*','states.name as sname'),array('states.country_id'=>231),$join,'',array('cities.id'=>'DESC'),'50');  
          if(isset($_POST['search'])){
            if($_POST['_state_id']=='all'){
                $join=array('states'=>'states.id=cities.state_id');
               $template['cities']=$this->Cities_model->getResult(array('cities.*','states.name as sname'),array('states.country_id'=>231),$join,'',array('cities.id'=>'DESC'),'50');
             }else{
              $join=array('states'=>'states.id=cities.state_id');
               $template['cities']=$this->Cities_model->getResult(array('cities.*','states.name as sname'),array('cities.state_id'=>$_POST['_state_id'],'states.country_id'=>231),$join,'',array('cities.id'=>'DESC'));
             }
              
            }
          $template['states']=$this->States_model->getResult(array('*'),array('country_id'=>'231'));
          
          $template['title']='Cities';
          $template['subtitle']='Cities & view city';
          $template['theme']='theme/cities';
          $template['ancher']='cities';
          if($this->CI->checkPermission('ct_4')){ 
              $template['page']='cities/cities';
            }else{
              $template['page']='access/index';
            }  
               
    	    $this->load->view('template',$template);
    	}

      public function edit($id) { 
         if($this->CI->checkPermission('ct_2')){     
            if(isset($_POST['save'])){
               $ids= $_POST['id'];
               $data =array('name'=>$_POST['name'],'state_id'=>$_POST['state_id']);
                $update = $this->Cities_model->update(array('id'=>$ids),$data);
              if($update){
                $this->session->set_flashdata('success', 'City updated successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('cities');
            }
          }else{
            $this->session->set_flashdata('error', 'You dont have access');
            redirect('cities');
          }
       }
        public function delete($id){
          if($this->CI->checkPermission('ct_3')){   
           $delete = $this->Cities_model->delete(array('id'=>$id));
           if($delete){
                $this->session->set_flashdata('success', 'City deleted successfully');
              }else{
                $this->session->set_flashdata('error', 'internal error !');
              }
              redirect('cities');
            }else{
              $this->session->set_flashdata('error', 'You dont have access');
              redirect('cities');
            }
        }
        
        
	    public function popup($page_name = '' , $param2 = '',$param3 = '' ){
           $page_data['param2']    = $param2;
           $page_data['param3']    = $param3;
           $this->load->view('cities/'.$page_name ,$page_data);
        }
}

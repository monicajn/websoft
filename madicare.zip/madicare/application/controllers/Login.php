<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    public function __construct(){
	   parent::__construct();
    }
	public function index(){
        if($this->session->userdata('id')){
              redirect('home');
        }
	   $this->load->view('login'); 
	}
	public function getAuth()
	{
		$email=$this->input->post('username');
		$password=md5($this->input->post('password'));
		$this->load->model('Login_model');
		$data=$this->Login_model->getAuth($email,$password);
         if ($data) {
                    $authuser=array(
                    	        'id' =>$data->id,
                    	        'userID'=>$data->userID,
                    	        'name'  =>$data->fname." ".$data->lname,
                    	        'type'  =>$data->type,
                    	        'email' =>$data->email,
                    	        'access'=>$data->access

                    	      );
		                $this->session->set_userdata($authuser);
		    echo 'success';
		}else{
			echo 'error';
		}

	}
	
	
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Insurance_model extends MY_Model {

	   public function __construct()
	{
        $this->table = 'insurance';
        $this->primary_key = 'id';
          parent::__construct();
	}
        
        
       

}

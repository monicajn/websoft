<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

	
	public function getAuth($username,$password)
	{   

		 $query = $this->db->select('*')->from('user')
                            ->where('password', $password)
                              ->group_start()
		                        ->where('email', $username)
		                        ->or_where('userID', $username)
		                        ->or_where('username', $username)
		                     ->group_end()
                            ->get();
			
				 if (count($query->row())>0) {
				 	return $query->row();
				 }else{
				 	return false;
				 }
	}


public function checkemail($email){
	   return $this->db->get_where('user',array('email'=>$email))->result_array();
	  }
	

}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Countries_model extends MY_Model {

	   public function __construct()
	{
        $this->table = 'countries';
        $this->primary_key = 'id';
          parent::__construct();
	}
        
        
       

}

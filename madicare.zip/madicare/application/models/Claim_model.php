<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Claim_model extends MY_Model {

	   public function __construct()
	{
        $this->table = 'claims';
        $this->primary_key = 'id';
          parent::__construct();
	}
        
        
       

}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customers_model extends MY_Model {

	   public function __construct()
	{
        $this->table = 'customer';
        $this->primary_key = 'customer_id';
          parent::__construct();
	}
        
        
       

}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cptcode_model extends MY_Model {

	   public function __construct()
	{
        $this->table = 'cptcode';
        $this->primary_key = 'id';
          parent::__construct();
	}
        
        
       

}

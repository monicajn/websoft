<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Doctors_model extends MY_Model {

	   public function __construct()
	{
        $this->table = 'doctors';
        $this->primary_key = 'id';
          parent::__construct();
	}
        
        
       

}

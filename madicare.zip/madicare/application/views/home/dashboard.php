                <!-- Content area -->
                <div class="content">

                    <!-- Dashboard content -->
                    <div class="row">
                        <div class="col-lg-8">

                              <!-- Quick stats boxes -->
                            <div class="row">
                                <div class="col-lg-4">

                                    <!-- Members online -->
                                    <div class="panel bg-teal-400">
                                        <div class="panel-body">
                                            <div class="heading-elements">
                                               <!--  <span class="heading-text badge bg-teal-800">+53,6%</span> -->
                                            </div>

                                            <h3 class="no-margin">3,450</h3>
                                            Today's Patient List
                                            <div class="text-muted text-size-small">489 avg</div>
                                        </div>

                                        <div class="container-fluid">
                                            <div id="members-online"></div>
                                        </div>
                                    </div>
                                    <!-- /members online -->

                                </div>
                              
                              <div class="col-lg-4">

                                    <!-- Today's revenue -->
                                    <div class="panel bg-pink-400">
                                        <div class="panel-body">
                                            <div class="heading-elements">
                                                <ul class="icons-list">
                                                    <li><a data-action="reload"></a></li>
                                                </ul>
                                            </div>

                                            <h3 class="no-margin">18,390</h3>
                                            Insurence Panding List
                                            <div class="text-muted text-size-small">view</div>
                                        </div>

                                        <div id="today-revenue"></div>
                                    </div>
                                    <!-- /today's revenue -->

                                </div>


                                <div class="col-lg-4">

                                    <!-- Today's revenue -->
                                    <div class="panel bg-blue-400">
                                        <div class="panel-body">
                                            <div class="heading-elements">
                                                <ul class="icons-list">
                                                    <li><a data-action="reload"></a></li>
                                                </ul>
                                            </div>

                                            <h3 class="no-margin">18,390</h3>
                                            Insurence Approved List
                                            <div class="text-muted text-size-small">view</div>
                                        </div>

                                        <div id="today-revenue"></div>
                                    </div>
                                    <!-- /today's revenue -->

                                </div>




                                <div class="col-lg-4">

                                    <!-- Today's revenue -->
                                    <div class="panel bg-blue-400">
                                        <div class="panel-body">
                                            <div class="heading-elements">
                                                <ul class="icons-list">
                                                    <li><a data-action="reload"></a></li>
                                                </ul>
                                            </div>

                                            <h3 class="no-margin">18,390</h3>
                                            Insurence Company List
                                            <div class="text-muted text-size-small">view</div>
                                        </div>

                                        <div id="today-revenue"></div>
                                    </div>
                                    <!-- /today's revenue -->

                                </div>
                                <div class="col-lg-4">

                                    <!-- Members online -->
                                    <div class="panel bg-teal-400">
                                        <div class="panel-body">
                                            <div class="heading-elements">
                                               <!--  <span class="heading-text badge bg-teal-800">+53,6%</span> -->
                                            </div>

                                            <h3 class="no-margin">3,450</h3>
                                            RECIEVABLES
                                            <div class="text-muted text-size-small">489 avg</div>
                                        </div>

                                        <div class="container-fluid">
                                            <div id="members-online"></div>
                                        </div>
                                    </div>
                                    <!-- /members online -->

                                </div>

                                 <div class="col-lg-4">

                                    <!-- Today's revenue -->
                                    <div class="panel bg-pink-400">
                                        <div class="panel-body">
                                            <div class="heading-elements">
                                                <ul class="icons-list">
                                                    <li><a data-action="reload"></a></li>
                                                </ul>
                                            </div>

                                            <h3 class="no-margin">18,390</h3>
                                           Reports
                                            <div class="text-muted text-size-small">view</div>
                                        </div>

                                        <div id="today-revenue"></div>
                                    </div>
                                    <!-- /today's revenue -->

                                </div>


                            </div>
                            <!-- /quick stats boxes -->


                            <!-- Marketing campaigns -->
                            <div class="panel panel-flat">
                                

                              

                                <div class="table-responsive">
                                    <table class="table text-nowrap">
                                        <thead>
                                            <tr>
                                                <th>Campaign</th>
                                                <th class="col-md-2">Client</th>
                                                <th class="col-md-2">Changes</th>
                                                <th class="col-md-2">Budget</th>
                                                <th class="col-md-2">Status</th>
                                                <th class="text-center" style="width: 20px;"><i class="icon-arrow-down12"></i></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="active border-double">
                                                <td colspan="5">Today</td>
                                                <td class="text-right">
                                                    <span class="progress-meter" id="today-progress" data-progress="30"></span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="media-left media-middle">
                                                        <a href="#"><img src="assets/images/brands/facebook.png" class="img-circle img-xs" alt=""></a>
                                                    </div>
                                                    <div class="media-left">
                                                        <div class=""><a href="#" class="text-default text-semibold">99213</a></div>
                                                        <div class="text-muted text-size-small">
                                                            <span class="status-mark border-blue position-left"></span>
                                                            60 Min(1)
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="text-muted">Psychotherapy </span></td>
                                                <td><span class="text-success-600"><i class="fa fa-dollar"></i> 2.43</span></td>
                                                <td><h6 class="text-semibold">$5,489</h6></td>
                                                <td><span class="label bg-blue">Active</span></td>
                                                <td class="text-center">
                                                    <ul class="icons-list">
                                                        <li class="dropdown">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-right">
                                                                <li><a href="#"><i class="icon-file-stats"></i> View statement</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="media-left media-middle">
                                                        <a href="#"><img src="assets/images/brands/facebook.png" class="img-circle img-xs" alt=""></a>
                                                    </div>
                                                    <div class="media-left">
                                                        <div class=""><a href="#" class="text-default text-semibold">90345</a></div>
                                                        <div class="text-muted text-size-small">
                                                            <span class="status-mark border-green position-left"></span>
                                                            30 Min(1)
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="text-muted">Psychotherapy </span></td>
                                                <td><span class="text-success-600"><i class="fa fa-dollar"></i> 1.43</span></td>
                                                <td><h6 class="text-semibold">$5,489</h6></td>
                                                <td><span class="label bg-green">Success</span></td>
                                                <td class="text-center">
                                                    <ul class="icons-list">
                                                        <li class="dropdown">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-right">
                                                                <li><a href="#"><i class="icon-file-stats"></i> View statement</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="media-left media-middle">
                                                        <a href="#"><img src="assets/images/brands/facebook.png" class="img-circle img-xs" alt=""></a>
                                                    </div>
                                                    <div class="media-left">
                                                        <div class=""><a href="#" class="text-default text-semibold">99213</a></div>
                                                        <div class="text-muted text-size-small">
                                                            <span class="status-mark border-blue position-left"></span>
                                                            60 Min(1)
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="text-muted">Psychotherapy </span></td>
                                                <td><span class="text-success-600"><i class="fa fa-dollar"></i> 2.43</span></td>
                                                <td><h6 class="text-semibold">$5,489</h6></td>
                                                <td><span class="label bg-blue">Active</span></td>
                                                <td class="text-center">
                                                    <ul class="icons-list">
                                                        <li class="dropdown">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-right">
                                                                <li><a href="#"><i class="icon-file-stats"></i> View statement</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="media-left media-middle">
                                                        <a href="#"><img src="assets/images/brands/facebook.png" class="img-circle img-xs" alt=""></a>
                                                    </div>
                                                    <div class="media-left">
                                                        <div class=""><a href="#" class="text-default text-semibold">99213</a></div>
                                                        <div class="text-muted text-size-small">
                                                            <span class="status-mark border-blue position-left"></span>
                                                            60 Min(1)
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="text-muted">Psychotherapy </span></td>
                                                <td><span class="text-success-600"><i class="fa fa-dollar"></i> 2.43</span></td>
                                                <td><h6 class="text-semibold">$5,489</h6></td>
                                                <td><span class="label bg-blue">Active</span></td>
                                                <td class="text-center">
                                                    <ul class="icons-list">
                                                        <li class="dropdown">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-right">
                                                                <li><a href="#"><i class="icon-file-stats"></i> View statement</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                             <tr>
                                                <td>
                                                    <div class="media-left media-middle">
                                                        <a href="#"><img src="assets/images/brands/facebook.png" class="img-circle img-xs" alt=""></a>
                                                    </div>
                                                    <div class="media-left">
                                                        <div class=""><a href="#" class="text-default text-semibold">90345</a></div>
                                                        <div class="text-muted text-size-small">
                                                            <span class="status-mark border-green position-left"></span>
                                                            30 Min(1)
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="text-muted">Psychotherapy </span></td>
                                                <td><span class="text-success-600"><i class="fa fa-dollar"></i> 1.43</span></td>
                                                <td><h6 class="text-semibold">$5,489</h6></td>
                                                <td><span class="label bg-green">Success</span></td>
                                                <td class="text-center">
                                                    <ul class="icons-list">
                                                        <li class="dropdown">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-right">
                                                                <li><a href="#"><i class="icon-file-stats"></i> View statement</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                             <tr>
                                                <td>
                                                    <div class="media-left media-middle">
                                                        <a href="#"><img src="assets/images/brands/facebook.png" class="img-circle img-xs" alt=""></a>
                                                    </div>
                                                    <div class="media-left">
                                                        <div class=""><a href="#" class="text-default text-semibold">90345</a></div>
                                                        <div class="text-muted text-size-small">
                                                            <span class="status-mark border-green position-left"></span>
                                                            30 Min(1)
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="text-muted">Psychotherapy </span></td>
                                                <td><span class="text-success-600"><i class="fa fa-dollar"></i> 1.43</span></td>
                                                <td><h6 class="text-semibold">$5,489</h6></td>
                                                <td><span class="label bg-green">Success</span></td>
                                                <td class="text-center">
                                                    <ul class="icons-list">
                                                        <li class="dropdown">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-right">
                                                                <li><a href="#"><i class="icon-file-stats"></i> View statement</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            
                                            <tr>
                                                <td>
                                                    <div class="media-left media-middle">
                                                        <a href="#"><img src="assets/images/brands/youtube.png" class="img-circle img-xs" alt=""></a>
                                                    </div>
                                                    <div class="media-left">
                                                        <div class=""><a href="#" class="text-default text-semibold"> 901234</a></div>
                                                        <div class="text-muted text-size-small">
                                                            <span class="status-mark border-danger position-left"></span>
                                                            29 Min(1)
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="text-muted">Test</span></td>
                                                <td><span class="text-success-600"><i class="fa fa-dollar"></i> 3.12</span></td>
                                                <td><h6 class="text-semibold">$2,592</h6></td>
                                                <td><span class="label bg-danger">Closed</span></td>
                                                <td class="text-center">
                                                    <ul class="icons-list">
                                                        <li class="dropdown">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-right">
                                                                <li><a href="#"><i class="icon-file-stats"></i> View statement</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="media-left media-middle">
                                                        <a href="#"><img src="assets/images/brands/spotify.png" class="img-circle img-xs" alt=""></a>
                                                    </div>
                                                    <div class="media-left">
                                                        <div class=""><a href="#" class="text-default text-semibold">987654</a></div>
                                                        <div class="text-muted text-size-small">
                                                            <span class="status-mark border-grey-400 position-left"></span>
                                                            10 Min(1)
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="text-muted">Diligence</span></td>
                                                <td><span class="text-danger"><i class="fa fa-dollar"></i> - 8.02%</span></td>
                                                <td><h6 class="text-semibold">$1,268</h6></td>
                                                <td><span class="label bg-grey-400">Hold</span></td>
                                                <td class="text-center">
                                                    <ul class="icons-list">
                                                        <li class="dropdown">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-right">
                                                                <li><a href="#"><i class="icon-file-stats"></i> View statement</a></li>
                                                                </ul>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="media-left media-middle">
                                                        <a href="#"><img src="assets/images/brands/twitter.png" class="img-circle img-xs" alt=""></a>
                                                    </div>
                                                    <div class="media-left">
                                                        <div class=""><a href="#" class="text-default text-semibold">Twitter ads</a></div>
                                                        <div class="text-muted text-size-small">
                                                            <span class="status-mark border-grey-400 position-left"></span>
                                                            04:00 - 05:00
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="text-muted">Deluxe</span></td>
                                                <td><span class="text-success-600"><i class="icon-stats-growth2 position-left"></i> 2.78%</span></td>
                                                <td><h6 class="text-semibold">$7,467</h6></td>
                                                <td><span class="label bg-grey-400">Hold</span></td>
                                                <td class="text-center">
                                                    <ul class="icons-list">
                                                        <li class="dropdown">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-right">
                                                                <li><a href="#"><i class="icon-file-stats"></i> View statement</a></li>
                                                                <li><a href="#"><i class="icon-file-text2"></i> Edit campaign</a></li>
                                                                <li><a href="#"><i class="icon-file-locked"></i> Disable campaign</a></li>
                                                                <li class="divider"></li>
                                                                <li><a href="#"><i class="icon-gear"></i> Settings</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>

                                            <tr class="active border-double">
                                                <td colspan="5">Yesterday</td>
                                                <td class="text-right">
                                                    <span class="progress-meter" id="yesterday-progress" data-progress="65"></span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="media-left media-middle">
                                                        <a href="#"><img src="assets/images/brands/bing.png" class="img-circle img-xs" alt=""></a>
                                                    </div>
                                                    <div class="media-left">
                                                        <div class=""><a href="#" class="text-default text-semibold">Bing campaign</a></div>
                                                        <div class="text-muted text-size-small">
                                                            <span class="status-mark border-success position-left"></span>
                                                            15:00 - 16:00
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="text-muted">Metrics</span></td>
                                                <td><span class="text-danger"><i class="icon-stats-decline2 position-left"></i> - 5.78%</span></td>
                                                <td><h6 class="text-semibold">$970</h6></td>
                                                <td><span class="label bg-success-400">Pending</span></td>
                                                <td class="text-center">
                                                    <ul class="icons-list">
                                                        <li class="dropup">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-right">
                                                                <li><a href="#"><i class="icon-file-stats"></i> View statement</a></li>
                                                                <li><a href="#"><i class="icon-file-text2"></i> Edit campaign</a></li>
                                                                <li><a href="#"><i class="icon-file-locked"></i> Disable campaign</a></li>
                                                                <li class="divider"></li>
                                                                <li><a href="#"><i class="icon-gear"></i> Settings</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="media-left media-middle">
                                                        <a href="#"><img src="assets/images/brands/amazon.png" class="img-circle img-xs" alt=""></a>
                                                    </div>
                                                    <div class="media-left">
                                                        <div class=""><a href="#" class="text-default text-semibold">Amazon ads</a></div>
                                                        <div class="text-muted text-size-small">
                                                            <span class="status-mark border-danger position-left"></span>
                                                            18:00 - 19:00
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="text-muted">Blueish</span></td>
                                                <td><span class="text-success-600"><i class="icon-stats-growth2 position-left"></i> 6.79%</span></td>
                                                <td><h6 class="text-semibold">$1,540</h6></td>
                                                <td><span class="label bg-blue">Active</span></td>
                                                <td class="text-center">
                                                    <ul class="icons-list">
                                                        <li class="dropup">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-right">
                                                                <li><a href="#"><i class="icon-file-stats"></i> View statement</a></li>
                                                                <li><a href="#"><i class="icon-file-text2"></i> Edit campaign</a></li>
                                                                <li><a href="#"><i class="icon-file-locked"></i> Disable campaign</a></li>
                                                                <li class="divider"></li>
                                                                <li><a href="#"><i class="icon-gear"></i> Settings</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="media-left media-middle">
                                                        <a href="#"><img src="assets/images/brands/dribbble.png" class="img-circle img-xs" alt=""></a>
                                                    </div>
                                                    <div class="media-left">
                                                        <div class=""><a href="#" class="text-default text-semibold">Dribbble ads</a></div>
                                                        <div class="text-muted text-size-small">
                                                            <span class="status-mark border-blue position-left"></span>
                                                            20:00 - 21:00
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><span class="text-muted">Teamable</span></td>
                                                <td><span class="text-danger"><i class="icon-stats-decline2 position-left"></i> 9.83%</span></td>
                                                <td><h6 class="text-semibold">$8,350</h6></td>
                                                <td><span class="label bg-danger">Closed</span></td>
                                                <td class="text-center">
                                                    <ul class="icons-list">
                                                        <li class="dropup">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-right">
                                                                <li><a href="#"><i class="icon-file-stats"></i> View statement</a></li>
                                                                <li><a href="#"><i class="icon-file-text2"></i> Edit campaign</a></li>
                                                                <li><a href="#"><i class="icon-file-locked"></i> Disable campaign</a></li>
                                                                <li class="divider"></li>
                                                                <li><a href="#"><i class="icon-gear"></i> Settings</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- /marketing campaigns -->


                          

                          


                            

                        </div>

                        <div class="col-lg-4">

                          


                            <!-- Daily sales -->
                            <div class="panel panel-flat">
                                <div class="panel-heading">
                                    <h6 class="panel-title">Insuranse stats</h6>
                                    <div class="heading-elements">
                                        <span class="heading-text">Balance: <span class="text-bold text-danger-600 position-right">$4,378</span></span>
                                        <ul class="icons-list">
                                            <li class="dropdown text-muted">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-cog3"></i> <span class="caret"></span></a>
                                                <ul class="dropdown-menu dropdown-menu-right">
                                                    <li><a href="#"><i class="icon-sync"></i> Update data</a></li>
                                                    <li><a href="#"><i class="icon-list-unordered"></i> Detailed log</a></li>
                                                    <li><a href="#"><i class="icon-pie5"></i> Statistics</a></li>
                                                    <li class="divider"></li>
                                                    <li><a href="#"><i class="icon-cross3"></i> Clear list</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="panel-body">
                                    <div id="sales-heatmap"></div>
                                </div>

                                <div class="table-responsive">
                                    <table class="table text-nowrap">
                                        <thead>
                                            <tr>
                                                <th>Company Name</th>
                                                <th>Total</th>
                                                <th>Balance</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($insurance as $row){?>
                                            <tr>
                                                <td>
                                                    <div class="media-body">
                                                        <div class="media-heading">
                                                            <a href="#" class="letter-icon-title"><?php echo $row['name'];?></a>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span class="text-muted text-size-small">$49.90</span>
                                                </td>
                                                <td>
                                                    <h6 class="text-semibold no-margin">$00.90</h6>
                                                </td>
                                            </tr>

                                            
                                           <?php } ?>
                                           
                                        

                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- /daily sales -->

                            <!-- Daily financials -->
                            <div class="panel panel-flat">
                                <div class="panel-heading">
                                    <h6 class="panel-title">Daily claim</h6>
                                    <div class="heading-elements">
                                        <form class="heading-form" action="#">
                                            <div class="form-group">
                                                <label class="checkbox checkbox-inline checkbox-switchery checkbox-right switchery-xs">
                                                    <input type="checkbox" class="switcher" id="realtime" checked="checked">
                                                    Realtime
                                                </label>
                                            </div>
                                        </form>
                                        <span class="badge bg-danger-400 heading-text">+86</span>
                                    </div>
                                </div>

                                <div class="panel-body">
                                    <div class="content-group-xs" id="bullets"></div>

                                    <ul class="media-list">
                                        <?php foreach ($claimesbydate as $row) { ?>
                                           
                                        

                                        <li class="media">
                                            <div class="media-left">
                                                <a href="#" class="btn border-success text-success btn-flat btn-rounded btn-icon btn-xs"><i class="icon-checkmark3"></i></a>
                                            </div>
                                            
                                            <div class="media-body">
                                                Claim by <a href="#"><?php echo $row['patientname']?></a> to  <a href="#"><?php echo $row['insurancename'];?></a> have been paid
                                                <div class="media-annotation">Dec 18, 18:36</div>
                                            </div>

                                            <div class="media-right media-middle">
                                                <ul class="icons-list">
                                                    <li>
                                                        <a href="#"><i class="icon-arrow-right13"></i></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <?php } ?>

                                        
                                    </ul>
                                </div>
                            </div>
                            <!-- /daily financials -->

                        </div>
                    </div>
                    <!-- /dashboard content -->


<?php $this->load->view('include/header'); ?>
<?php $this->load->view($page); ?>
<?php $this->load->view($theme); ?>
<?php $this->load->view('include/footer'); ?>

<!-- Footer -->
					<!-- <div class="footer text-muted">
						&copy; 2018. <a href="#">Real State Construction LTD</a> by <a href="#" target="_blank">Redbox</a>
					</div> -->
					<!-- /footer -->

				</div>
				<!-- /content area -->

			</div>
			<!-- /main content -->

		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->
         <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/notifications/jgrowl.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/notifications/bootbox.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/pages/components_notifications_other.js"></script>
         <?php if ($this->session->flashdata('success')): ?>
            <script type="text/javascript">
         
              $.jGrowl("<?=$this->session->flashdata('success');?>", {
                header: 'Success',
                theme: 'alert-styled-left bg-success'
             });
          </script>
          <?php endif ?>
        <?php if ($this->session->flashdata('error')): ?>
              <script type="text/javascript">
             
             $.jGrowl("<?=$this->session->flashdata('error');?>", {
            header: 'Error',
            theme: 'alert-styled-left bg-danger'
        });
          </script>
          <?php endif ?>
</body>

<!-- Mirrored from demo.interface.club/limitless/layout_1/LTR/default/layout_navbar_sidebar_fixed.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jan 2018 12:13:58 GMT -->
</html>

  
        
           <!-- Theme JS files -->
	<link href="<?php echo base_url();?>assets/css/select2.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>assets/css/datatable/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>assets/css/datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
 <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/styling/uniform.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/styling/switchery.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/styling/switch.min.js"></script>
   <script type="text/javascript" src="<?php echo base_url();?>assets/js/core/app.js"></script>
 <script type="text/javascript" src="<?php echo base_url();?>assets/js/pages/form_checkboxes_radios.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/jszip.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/pdfmake.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/vfs_fonts.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.print.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.colVis.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/select2/select2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/script.js"></script>
       <style>
             .table thead tr {border: 1px solid #111;}
       .dataTables_filter ,.dt-buttons{
            margin: 12px 0 11px 20px !important;
       } 
       </style>
      <script>
           
             $('body').on('click','.parentclass',function(e){
               if ($(this).prop('checked')==true){ 
                  var pid = $(this).attr('id');
                  $('label.'+pid).find('div.checker') .removeClass('disabled');
                  $('.'+pid+'_ch').prop('disabled',false);
                  $('.'+pid+'_ch').attr('disabled',false);
               }else{
                  var pid = $(this).attr('id');
                   $('label.'+pid).find('div.checker>span').removeClass('checked');
                   $('label.'+pid).find('div.checker') .addClass('disabled');
                  $('.'+pid+'_ch').prop('disabled',true);
                  $('.'+pid+'_ch').attr('disabled',true);
                  $('.'+pid+'_ch').prop('checked',false);
                  $('.'+pid+'_ch').attr('checked',false);
               }
             });
            
            $('body').on('change','#state_id',function(e){
              var id = $(this).val();
              $.ajax({   
                 type: 'post',
                 url: '<?php echo base_url();?>crud/getcity',
                 data:"state_id="+id,
                 success:function (response)
                    {   
                        var returnedData = JSON.parse(response);
                        $('#city_id').empty().trigger("change");
                          jQuery.each(returnedData, function(index, item) {
                            var newState = new Option(item['value'], item['id'], true, true);
                           $("#city_id").append(newState).trigger('change');
                            $('#city_id').val('').trigger("change");
                           // $('.select2 ').css('border','1px solid #ccc;');
                        });
                    }
                });
            });
          
            $('body').on('click','.changest',function(e){
                  var id = $(this).data('id');
                  var st = $(this).data('status');
                if(st==1){   var val = 0; var msg = "You want to Inactive ?" }
                else{  var val =1;var msg = "You want to Active ?"; }
                  var dialog = bootbox.dialog({
                  title: 'Confirmation',
                  message: "<h4>Sure,"+msg+"</h4>",
                  size: 'small',
                  buttons: {
                      cancel: {
                          label: "Cancel",
                          className: 'btn-danger',
                          callback: function(){
                              dialog.modal('hide');
                          }
                      },
                     
                      ok: {
                          label: "OK",
                          className: 'btn-info',
                          callback: function(){
                            $.ajax({   
                               type: 'post',
                               url: '<?php echo base_url();?>team/changestatus',
                               data:"id="+id+"&st="+val,
                               dataType: 'json',
                               success:function (response)
                                  {   
                                    var status = $.trim(response['status']);
                                    if(status=='success'){
                                       window.location.href="<?php echo base_url();?>team";
                                     }
                                }
                              });
                            
                          }
                      }
                   }
                  });
            });

         $('body').on('click','.delete',function(e){
                  var id = $(this).data('id');
                  
                  var dialog = bootbox.dialog({
                  title: 'Confirmation',
                  message: "<h4>Sure, do you want to delete ?</h4>",
                  size: 'small',
                  buttons: {
                      cancel: {
                          label: "Cancel",
                          className: 'btn-danger',
                          callback: function(){
                              dialog.modal('hide');
                          }
                      },
                     
                      ok: {
                          label: "OK",
                          className: 'btn-info',
                          callback: function(){
                            window.location.href="<?php echo base_url();?>team/delete/"+id;
                          }
                      }
                   }
                  });
            });

  $('body').on('submit','#AddcityForm',function(e){
     e.preventDefault();
      var data = $(this).serialize();
     $.ajax({
                url: "<?php echo base_url();?>crud/addcity",
                type: "POST",
                data: data,
                success: function (response) {
                  $('#modal_ajax').modal('hide');
                  var returnedData = JSON.parse(response);
                 $('#city_id').empty().trigger("change");

                          jQuery.each(returnedData, function(index, item) {
                            var newState = new Option(item['value'], item['id'], true, true);
                           $("#city_id").append(newState).trigger('change');
                           $('#city_id').val('').trigger("change");
                         });
                },
                error: function (jXHR, textStatus, errorThrown) {
                   alert(errorThrown); 
                }
            }); 
  });
        </script>

        <!-- Primary modal -->
          <div id="modal_ajax" class="modal fade">
            <div class="modal-dialog">
              <div class="modal-content">
                    <form class="modelForm" action="#" method="POST">
                <div class="modal-header bg-primary">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h6 class="modal-title"><span id="modaltitle">Primary header</span></h6>
                </div>

                <div class="modal-body">
                                                                    
                </div>

                <div class="modal-footer">
<!--                  <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary">Save changes</button>-->
                </div>
                   </form>
              </div>
            </div>
          </div>
<!-- /primary modal -->
            
        <!-- /theme JS files -->
  
        
           <!-- Theme JS files -->
	<link href="<?php echo base_url();?>assets/css/select2.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>assets/css/datatable/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>assets/css/datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
 <script type="text/javascript" src="<?php echo base_url();?>assets/js/core/app.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/jszip.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/pdfmake.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/vfs_fonts.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.print.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.colVis.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/select2/select2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/script.js"></script>
       <style>
             .table thead tr {border: 1px solid #111;}
       .dataTables_filter ,.dt-buttons{
            margin: 12px 0 11px 20px !important;
       } 
       </style>
       <script type="text/javascript">
         $('body').on('click','.delete',function(e){
                  var id = $(this).data('id');
                  
                  var dialog = bootbox.dialog({
                  title: 'Confirmation',
                  message: "<h4>Sure, do you want to delete ?</h4>",
                  size: 'small',
                  buttons: {
                      cancel: {
                          label: "Cancel",
                          className: 'btn-danger',
                          callback: function(){
                              dialog.modal('hide');
                          }
                      },
                     
                      ok: {
                          label: "OK",
                          className: 'btn-info',
                          callback: function(){
                            window.location.href="<?php echo base_url();?>cptcode/delete/"+id;
                          }
                      }
                   }
                  });
            });
       </script>

        <!-- Primary modal -->
          <div id="modal_ajax" class="modal fade">
            <div class="modal-dialog">
              <div class="modal-content">
                    <form class="modelForm" action="#" method="POST">
                <div class="modal-header bg-primary">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h6 class="modal-title"><span id="modaltitle">Primary header</span></h6>
                </div>

                <div class="modal-body">
                                                                    
                </div>

                <div class="modal-footer">
<!--                  <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary">Save changes</button>-->
                </div>
                   </form>
              </div>
            </div>
          </div>
<!-- /primary modal -->
            
        <!-- /theme JS files -->
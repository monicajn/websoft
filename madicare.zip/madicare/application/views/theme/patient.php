  
        
           <!-- Theme JS files -->
	<link href="<?php echo base_url();?>assets/css/select2.css" rel="stylesheet" type="text/css">
   <link href="<?php echo base_url();?>assets/css/datatable/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url();?>assets/css/datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
     <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/styling/uniform.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/styling/switchery.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/styling/switch.min.js"></script>
 <script type="text/javascript" src="<?php echo base_url();?>assets/js/core/app.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/pages/form_checkboxes_radios.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/jszip.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/pdfmake.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/vfs_fonts.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.print.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.colVis.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/select2/select2.min.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>assets/js/script.js"></script>
       <style>
             .table thead tr {border: 1px solid #111;}
       .dataTables_filter ,.dt-buttons{
            margin: 12px 0 11px 20px !important;
            
       }

/****** CODE ******/

.file-upload{display:block;text-align:center;font-family: Helvetica, Arial, sans-serif;font-size: 12px;}
.file-upload .file-select{display:block;border: 2px solid #dce4ec;color: #34495e;cursor:pointer;height:40px;line-height:40px;text-align:left;background:#FFFFFF;overflow:hidden;position:relative;}
.file-upload .file-select .file-select-button{background:#dce4ec;padding:0 10px;display:inline-block;height:40px;line-height:40px;}
.file-upload .file-select .file-select-name{line-height:40px;display:inline-block;padding:0 10px;}
.file-upload .file-select:hover{border-color:#34495e;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload .file-select:hover .file-select-button{background:#34495e;color:#FFFFFF;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload.active .file-select{border-color:#3fa46a;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload.active .file-select .file-select-button{background:#3fa46a;color:#FFFFFF;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload .file-select input[type=file]{z-index:100;cursor:pointer;position:absolute;height:100%;width:100%;top:0;left:0;opacity:0;filter:alpha(opacity=0);}
.file-upload .file-select.file-select-disabled{opacity:0.65;}
.file-upload .file-select.file-select-disabled:hover{cursor:default;display:block;border: 2px solid #dce4ec;color: #34495e;cursor:pointer;height:40px;line-height:40px;margin-top:5px;text-align:left;background:#FFFFFF;overflow:hidden;position:relative;}
.file-upload .file-select.file-select-disabled:hover .file-select-button{background:#dce4ec;color:#666666;padding:0 10px;display:inline-block;height:40px;line-height:40px;}
.file-upload .file-select.file-select-disabled:hover .file-select-name{line-height:40px;display:inline-block;padding:0 10px;}
       </style>
       <script type="text/javascript">
         $('body').on('change','#state_id',function(e){
              var id = $(this).val();
              $.ajax({   
                 type: 'post',
                 url: '<?php echo base_url();?>crud/getcity',
                 data:"state_id="+id,
                 success:function (response)
                    {   
                        var returnedData = JSON.parse(response);
                        $('#city_id').empty().trigger("change");
                          jQuery.each(returnedData, function(index, item) {
                            var newState = new Option(item['value'], item['id'], true, true);
                           $("#city_id").append(newState).trigger('change');
                           $('#city_id').val('').trigger("change");
                           // $('.select2 ').css('border','1px solid #ccc;');
                        });
                    }
                });
            });

  
  
$('body').on('submit','#AddcityForm',function(e){
     e.preventDefault();
      var data = $(this).serialize();
     $.ajax({
                url: "<?php echo base_url();?>crud/addcity",
                type: "POST",
                data: data,
                success: function (response) {
                  $('#modal_ajax').modal('hide');
                  var returnedData = JSON.parse(response);
                 $('#city_id').empty().trigger("change");

                          jQuery.each(returnedData, function(index, item) {
                            var newState = new Option(item['value'], item['id'], true, true);
                           $("#city_id").append(newState).trigger('change');
                           $('#city_id').val('').trigger("change");
                         });
                },
                error: function (jXHR, textStatus, errorThrown) {
                   alert(errorThrown); 
                }
            }); 
  });
          $('body').on('keyup','.checkempty',function(e){
             var fname = $('#fname').val();
            var lname = $('#lname').val();
             if(fname!='' && lname!=''){
              $('#dob').prop('disabled',false);
              $('#dob').attr('disabled',false);
             }else{
               $('#dob').val('');
               $('#dob').prop('disabled',true);
               $('#dob').attr('disabled',true);

             }
          })
         
         

         $('body').on('click','.delete',function(e){
                  var id = $(this).data('id');
                  
                  var dialog = bootbox.dialog({
                  title: 'Confirmation',
                  message: "<h4>Sure, do you want to delete ?</h4>",
                  size: 'small',
                  buttons: {
                      cancel: {
                          label: "Cancel",
                          className: 'btn-danger',
                          callback: function(){
                              dialog.modal('hide');
                          }
                      },
                     
                      ok: {
                          label: "OK",
                          className: 'btn-info',
                          callback: function(){
                            window.location.href="<?php echo base_url();?>patient/delete/"+id;
                          }
                      }
                   }
                  });
            });

$(document).ready(function () {
            $('.checkAll').on('click', function () {
               if ($(this).prop('checked')==true){ 
                     $('#example').DataTable()
                                          .column(0)
                                          .nodes()
                                          .to$()
                                          .find('label.tdinline>div.checker>span')
                                          .addClass('checked');
                         $('#example').DataTable()
                                          .column(0)
                                          .nodes()
                                          .to$()
                                          .find('input[type=checkbox]')
                                          .prop('checked',true);
                        $('#example').DataTable()
                                          .column(0)
                                          .nodes()
                                          .to$()
                                          .find('input[type=checkbox]')
                                          .attr('checked',true);
                   
               }else{
                   $('#example').DataTable()
                                          .column(0)
                                          .nodes()
                                          .to$()
                                          .find('label.tdinline>div.checker>span')
                                          .removeClass('checked');
                         $('#example').DataTable()
                                          .column(0)
                                          .nodes()
                                          .to$()
                                          .find('input[type=checkbox]')
                                          .prop('checked',false);
                        $('#example').DataTable()
                                          .column(0)
                                          .nodes()
                                          .to$()
                                          .find('input[type=checkbox]')
                                          .attr('checked',false);
               }
            });
          });
         $(document).ready(function() {
            var table = $('#example').DataTable();
           
           $('body').on('click','#go',function(e){
             var len = table.$('[name="pids[]"]:checked').length;
             if(len>0){
                
                var dialog = bootbox.dialog({
                  title: 'Confirmation',
                  message: "<h4>Sure, do you want to delete ?</h4>",
                  size: 'small',
                  buttons: {
                      cancel: {
                          label: "Cancel",
                          className: 'btn-danger',
                          callback: function(){
                              dialog.modal('hide');
                          }
                      },
                     
                      ok: {
                          label: "OK",
                          className: 'btn-info',
                          callback: function(){
                                   dialog.modal('hide');
                                   var data = table.$('input, select').serialize();
                                  var action  = $('#action').val();
                                    $.ajax({   
                                       type: 'post',
                                       url: '<?php echo base_url();?>patient/patientAction',
                                       data:data+"&action="+action,
                                       success:function (response)
                                          {  
                                           window.location.href="<?php echo base_url();?>patient"; 
                                         }
                                 });
                          }
                      }
                   }
                  });
                
              }else{
                alert('please select atleast one');
              }
                return false;
             
            } );
        } );
        
         $('body').on('change','#chooseFile',function(e){
            var ext = $('#chooseFile').val().split('.').pop().toLowerCase();
            var filename = $("#chooseFile").val();
              if (/^\s*$/.test(filename)) {
                $(".file-upload").removeClass('active');
                $("#noFile").text("No file chosen..."); 
                 $('#uploadBtn').prop('disabled',true);
                $('#uploadBtn').attr('disabled',true);
              }else {
                $(".file-upload").addClass('active');
                $("#noFile").text(filename.replace("C:\\fakepath\\", ""));
               if(ext=="xlsx"){
                     $('#uploadBtn').prop('disabled',false);
                     $('#uploadBtn').attr('disabled',false);
                  }else{
                     $('#uploadBtn').prop('disabled',true);
                     $('#uploadBtn').attr('disabled',true);
                     $('#ImportForm')[0].reset();
                     alert(ext+" File type not allowed");
                  }
               }
          });


         function insertpatient(fname,mname,lname ,dob,email , mobile ,address ,pregnant ,sex,insurance_member_id,insurance_company,state_id,city_id,zipcode) {
          var formdata = "fname="+fname+"&lname="+lname+"&dob="+dob+"&mobile="+mobile+"&email="+email+"&address="+address+"&pregnant="+pregnant+"&sex="+sex+"&insurance_member_id="+insurance_member_id+"&insurance_company="+insurance_company+"&state_id="+state_id+"&city_id="+city_id+"&zipcode="+zipcode;
           $.ajax({   
                         type: 'post',
                         url: '<?php echo base_url();?>patient/savedata',
                         data:formdata,
                         success:function (response)
                            { 
                              var str=$.trim(response);
                           }
                       });
         }
      function loadItems() {
         //localStorage.removeItem('patientimport'); 
        if(JSON.parse(localStorage.getItem('patientimport'))) {
        var sortedSale = JSON.parse(localStorage.getItem('patientimport'));
        var outputs = "";
        $("#resultlist").empty();
         outputs +='<table  class="table table-bordered" cellspacing="0" width="100%"><thead><tr><th>Name</th><th>Email</th><th>Mobile</th><th>state</th><th>status</th><th>Update</th></tr></thead><tbody>';
       var cnt=1;var updts=0;
        $.each(sortedSale, function () {
             var result = this;
             var status='';var action='';
             if(result.pid==0 && result.st==0){
               status = "<span class='text-success'><b>Inserted</b></span>";
               action = '-';
             }else{
              status = "<span class='text-warning'><b>Duplicate</b></span>";
              action ='<div class="checkbox-inline" style=""><input type="checkbox" value="yes" name="chk_'+cnt+'" class="styled">YES</div>';
              updts++;
             }
             outputs +='<tr class="rowid'+result.pid+'">'
                           +'<td><input class="pid" name="pid'+cnt+'" type="hidden"  value="'+result.pid+'"><input class="fname" type="hidden" name="fname'+cnt+'" value="'+result.fname+'"><input class="mname"  type="hidden" name="mname'+cnt+'" value="'+result.mname+'"><input class="lname"  type="hidden" name="lname'+cnt+'" value="'+result.lname+'">'+result.fname+' '+result.lname+'</td>'

                            +'<td><input class="email"  type="hidden" name="email'+cnt+'" value="'+result.email+'">'+result.email+'</td>'
                            +'<td><input class="mobile"  type="hidden" name="mobile'+cnt+'" value="'+result.mobile+'">'+result.mobile+'</td>'
                            +'<td>'
                            +'<input class="address"  type="hidden" name="address'+cnt+'" value="'+result.address+'">'
                            +'<input class="pregnant"  type="hidden" name="pregnant'+cnt+'" value="'+result.pregnant+'">'
                            +'<input class="sex"  type="hidden" name="sex'+cnt+'" value="'+result.sex+'">'
                            +'<input class="insurance_member_id"  type="hidden" name="insurance_member_id'+cnt+'" value="'+result.insurance_member_id+'">'
                            +'<input class="insurance_company"  type="hidden" name="insurance_company'+cnt+'" value="'+result.insurance_company+'">'
                            +'<input class="city"  type="hidden" name="city_id'+cnt+'" value="'+result.city_id+'">'
                            +'<input class="state"  type="hidden" name="state_id'+cnt+'" value="'+result.state_id+'">'
                            +'<input class="zipcode"  type="hidden" name="zipcode'+cnt+'" value="'+result.zipcode+'">'+result.address
                            +'</td>'
                            +'<td>'+status+'</td>'
                            +'<td>'+action+'</td>'

                           +'</tr>';   
           cnt++;                         
         }) ;  
        outputs +="</tbody></table><input type='hidden' value='"+cnt+"' name='counter'>";
        if(updts>0){
            outputs +='<div class="row" style="margin: 15px 0 0 0;"><div class="col-md-10"> </div>' 
                       +'<div class="col-md-1">'
                          +'<button style="" class="btn btn-info" type="submit" name="update"  ><i class="fa fa-file" ></i>&nbsp; UPDATE</button>'
                       +'</div>' 
                        +'<div class="col-md-1">'
                           +'<button data-src="patient" class="btn btn-danger redirect" type="button" name="Cancel" ><i class="icon-undo2" ></i>&nbsp; Cancel</button>'
                       +'</div> </div>';
           }else{
              outputs +='<div class="row" style="margin: 15px 0 0 0;"><div class="col-md-11"> </div>'
                         +'<div class="col-md-1">'
                            +'<button data-src="patient" class="btn btn-danger redirect" type="button" name="Cancel" ><i class="icon-undo2" ></i>&nbsp; OK</button>'
                         +'</div> </div>';
           }
        
         $('#resultlist').html(outputs);
         $(".file-upload").removeClass('active');
                $("#noFile").text("No file chosen..."); 
                $('#ImportForm')[0].reset();
                $('#uploadBtn').prop('disabled',true);
                     $('#uploadBtn').attr('disabled',true);
         //console.log(localStorage.getItem('patientimport'));
      }
    }

          function addtolocal(i,st,pid,fname,mname,lname ,email , mobile ,address ,pregnant ,sex,insurance_member_id,insurance_company,state_id,city_id,zipcode){
            
             if(localStorage.getItem('patientimport')){
                 var patientimport = JSON.parse(localStorage.getItem('patientimport'));
              }else{
                 var patientimport ={}; 
                 }
              
               patientimport[i] = {st:st,pid:pid,fname:fname,mname:mname,lname:lname ,email:email,mobile:mobile,address:address,pregnant:pregnant,sex:sex,insurance_member_id:insurance_member_id,insurance_company:insurance_company,state_id:state_id,city_id:city_id,zipcode:zipcode};
               
               localStorage.setItem("patientimport", JSON.stringify(patientimport)); 
                loadItems();
            

      }

           function checkexist(i,fname,mname,lname ,dob,email , mobile ,address ,pregnant ,sex,insurance_member_id,insurance_company,state_id,city_id,zipcode){
                 $.ajax({   
                         type: 'post',
                         url: '<?php echo base_url();?>patient/checkPatientExistimport',
                         data:"fname="+fname+"&lname="+lname+"&mobile="+mobile,
                         dataType: 'json',
                         success:function (result)
                            { 
                              var status = $.trim(result['status']);
                               //console.log(result);
                                var pid = $.trim(result['pid']);
                             if(status=='error'){
                                var st="1";
                                addtolocal(i,st,pid,fname,mname,lname ,email , mobile ,address ,pregnant ,sex,insurance_member_id,insurance_company,state_id,city_id,zipcode);
                             }else{ 
                                insertpatient(fname,mname,lname ,dob,email , mobile ,address ,pregnant ,sex,insurance_member_id,insurance_company,state_id,city_id,zipcode);  
                                var st="0";
                                addtolocal(i,st,pid,fname,mname,lname ,email , mobile ,address ,pregnant ,sex,insurance_member_id,insurance_company,state_id,city_id,zipcode);
                             } 
                            
                           }
                       });
                
           }
           $('body').on('click','#uploadBtn',function(e){
              $('#ImportForm').submit();
           });

           $('body').on('submit','#ImportForm',function(e){
              e.preventDefault();
                $.ajax({   
                     url:"<?php echo base_url();?>patient/importexcelfile",  
                     method:"POST",  
                     data:new FormData(this),  
                     contentType:false,          // The content type used when sending data to the server.  
                     cache:false,                // To unable request pages to be cached  
                     processData:false,          // To send DOMDocument or non processed data file it is set to false  
                     success:function (response){
                       var json_obj = $.parseJSON(response);
                       for (var i in json_obj){   
                          console.log(json_obj[i]);
                          var fname =json_obj[i].fname; var lname = json_obj[i].lname;var mname = json_obj[i].mname;
                          var email =json_obj[i].email; var mobile = json_obj[i].mobile; 
                          var address= json_obj[i].address; var pregnant= json_obj[i].pregnant;  
                          var sex= json_obj[i].sex;  var insurance_member_id= json_obj[i].insurance_member_id;
                          var insurance_company= json_obj[i].insurance_company;
                          var state_id =json_obj[i].state_id; var city_id = json_obj[i].city_id;var zipcode = json_obj[i].zipcode;
                          var dob= "06/06/1990";
                        checkexist(i,fname,mname,lname ,dob,email,mobile ,address ,pregnant ,sex,insurance_member_id,insurance_company,state_id,city_id,zipcode);
                       }
                     }
                  });
             
          });
          $('body').on('click','.downloadfile',function(e){
               window.location.href="<?php echo base_url();?>patient/downloadfile";
            });
       </script>
     
          
       
      <!-- Primary modal -->
          <div id="modal_ajax" class="modal fade">
            <div class="modal-dialog">
              <div class="modal-content">
                    <form class="modelForm" action="#" method="POST">
                <div class="modal-header bg-primary">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h6 class="modal-title"><span id="modaltitle">Primary header</span></h6>
                </div>

                <div class="modal-body">
                                                                    
                </div>

                <div class="modal-footer">
<!--                  <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary">Save changes</button>-->
                </div>
                   </form>
              </div>
            </div>
          </div>
<!-- /primary modal -->
  
        
           <!-- Theme JS files -->
	<link href="<?php echo base_url();?>assets/css/select2.css" rel="stylesheet" type="text/css">
   <link href="<?php echo base_url();?>assets/css/datatable/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url();?>assets/css/datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
 <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/styling/uniform.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/styling/switchery.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/styling/switch.min.js"></script>
   <script type="text/javascript" src="<?php echo base_url();?>assets/js/core/app.js"></script>
 <script type="text/javascript" src="<?php echo base_url();?>assets/js/pages/form_checkboxes_radios.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/jszip.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/pdfmake.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/vfs_fonts.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.print.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/datatable/buttons.colVis.min.js"></script>
       <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/select2/select2.min.js"></script>
       <script type="text/javascript" src="<?php echo base_url();?>assets/js/script.js"></script>
       <style>
             .table thead tr {border: 1px solid #111;}
             .dataTables_filter ,.dt-buttons{
                margin: 12px 0 11px 20px !important;
             } 
             /****** CODE ******/

.file-upload{display:block;text-align:center;font-family: Helvetica, Arial, sans-serif;font-size: 12px;}
.file-upload .file-select{display:block;border: 2px solid #dce4ec;color: #34495e;cursor:pointer;height:40px;line-height:40px;text-align:left;background:#FFFFFF;overflow:hidden;position:relative;}
.file-upload .file-select .file-select-button{background:#dce4ec;padding:0 10px;display:inline-block;height:40px;line-height:40px;}
.file-upload .file-select .file-select-name{line-height:40px;display:inline-block;padding:0 10px;}
.file-upload .file-select:hover{border-color:#34495e;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload .file-select:hover .file-select-button{background:#34495e;color:#FFFFFF;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload.active .file-select{border-color:#3fa46a;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload.active .file-select .file-select-button{background:#3fa46a;color:#FFFFFF;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload .file-select input[type=file]{z-index:100;cursor:pointer;position:absolute;height:100%;width:100%;top:0;left:0;opacity:0;filter:alpha(opacity=0);}
.file-upload .file-select.file-select-disabled{opacity:0.65;}
.file-upload .file-select.file-select-disabled:hover{cursor:default;display:block;border: 2px solid #dce4ec;color: #34495e;cursor:pointer;height:40px;line-height:40px;margin-top:5px;text-align:left;background:#FFFFFF;overflow:hidden;position:relative;}
.file-upload .file-select.file-select-disabled:hover .file-select-button{background:#dce4ec;color:#666666;padding:0 10px;display:inline-block;height:40px;line-height:40px;}
.file-upload .file-select.file-select-disabled:hover .file-select-name{line-height:40px;display:inline-block;padding:0 10px;}
       </style>
       <script type="text/javascript">
        $(document).ready(function () {
            $('.checkAll').on('click', function () {
               if ($(this).prop('checked')==true){ 
                     $('#example').DataTable()
                                          .column(0)
                                          .nodes()
                                          .to$()
                                          .find('label.tdinline>div.checker>span')
                                          .addClass('checked');
                         $('#example').DataTable()
                                          .column(0)
                                          .nodes()
                                          .to$()
                                          .find('input[type=checkbox]')
                                          .prop('checked',true);
                        $('#example').DataTable()
                                          .column(0)
                                          .nodes()
                                          .to$()
                                          .find('input[type=checkbox]')
                                          .attr('checked',true);
                   
               }else{
                   $('#example').DataTable()
                                          .column(0)
                                          .nodes()
                                          .to$()
                                          .find('label.tdinline>div.checker>span')
                                          .removeClass('checked');
                         $('#example').DataTable()
                                          .column(0)
                                          .nodes()
                                          .to$()
                                          .find('input[type=checkbox]')
                                          .prop('checked',false);
                        $('#example').DataTable()
                                          .column(0)
                                          .nodes()
                                          .to$()
                                          .find('input[type=checkbox]')
                                          .attr('checked',false);
               }
            });
          });
         $(document).ready(function() {
            var table = $('#example').DataTable();
           
           $('body').on('click','#go',function(e){
             var len = table.$('[name="ids[]"]:checked').length;
             if(len>0){
                var data = table.$('input, select').serialize();
                var action  = $('#action').val();
                $.ajax({   
                     type: 'post',
                     url: '<?php echo base_url();?>claim/updateBulkstatus',
                     data:data+"&action="+action,
                     success:function (response)
                        {   
                          console.log(response);
                          $('#searchForm').submit();
                           //window.location.href="<?php //echo base_url();?>claim";
                      }
                    });
              }else{
                alert('please select atleast one');
              }
                return false;
             
            } );
        } );
         $('body').on('keyup','.decimal',function(e){
           if(event.which >= 37 && event.which <= 40){
                    event.preventDefault();
             }

                $(this).val(function(index, value) {
                  return value
                    .replace(/\D/g, "")
                    .replace(/([0-9])([0-9]{2})$/, '$1.$2')  
                   // .replace(/\B(?=(\d{3})+(?!\d)\.?)/g, ",")
                  ;
                });
              });
         $('body').on('keyup','.calculate',function(e){
          
          
          var quantity = $('#quantity').val();
          var rate = $('#rate').val();
          var by_pt = $('#by_pt').val();
          var by_claim = $('#by_claim').val();
          var total = $('#total_invoice').val();
          if(quantity==''){ quantity=0;}
          if(rate==''){ rate=0;}
          if(by_claim==''){ by_claim=0;}
          if(by_pt==''){ by_pt=0;}
          
           var multi = parseFloat(parseFloat(rate)*parseFloat(quantity)).toFixed(2);
            var extraper = parseFloat((parseFloat(multi)*parseFloat(15))/parseInt(100)).toFixed(2);
            
           var total = parseFloat(parseFloat(extraper)+parseFloat(multi)).toFixed(2);
           $('#total_invoice').val(total);
          // console.log(total);
           var sum  = parseFloat(parseFloat(by_claim)+parseFloat(by_pt)).toFixed(2);
           $('#amount_received').val(sum);
           var bal = parseFloat(parseFloat(total)-parseFloat(sum)).toFixed(2);
           $('#balance').val(bal);
         });

         $('body').on('click','.delete',function(e){
                  var id = $(this).data('id');
                  
                  var dialog = bootbox.dialog({
                  title: 'Confirmation',
                  message: "<h4>Sure, do you want to delete ?</h4>",
                  size: 'small',
                  buttons: {
                      cancel: {
                          label: "Cancel",
                          className: 'btn-danger',
                          callback: function(){
                              dialog.modal('hide');
                          }
                      },
                     
                      ok: {
                          label: "OK",
                          className: 'btn-info',
                          callback: function(){
                            window.location.href="<?php echo base_url();?>claim/delete/"+id;
                          }
                      }
                   }
                  });
            });

          // $('body').on('click','#go',function(e){
          //   var len = $('[name="ids[]"]:checked').length;
          //   var table = $('#example').DataTable();

          //     if(len>0){
          //       // $('#actionForm').submit();
          //        var data = table.$('input["type=checkbox"],select').serialize();
          //        $.ajax({   
          //            type: 'post',
          //            url: '<?php //echo base_url();?>claim/updateBulkstatus',
          //            data:data,
          //            dataType: 'json',
          //            success:function (response)
          //               {   
          //                 console.log(response);
          //                 // window.location.href="<?php //echo base_url();?>claim";
          //             }
          //           });
          //      }else{
          //        alert('please select atleast one');
          //     }
          //  });

     
         $('body').on('change','#cpt_code',function(e){
              var id = $(this).val();
              $.ajax({   
                 type: 'post',
                 url: '<?php echo base_url();?>crud/getcptdata',
                 data:"cpt="+id,
                 dataType:'json',
                 success:function (result)
                    {   
                        var status = $.trim(result['status']);
                        var rate = $.trim(result['rate']);
                        var dis = $.trim(result['description']);
                       if(status=='success'){
                          $('#rate').val(rate);
                          $('#description').val(dis);
                       }else{
                         alert('code not availabel');
                       }
                    }
                });
            });
           /* function update_status(id,st){
               $.ajax({   
                     type: 'post',
                     url: '<?php //echo base_url();?>claim/changestatus',
                     data:"id="+id+"&st="+st,
                     dataType: 'json',
                     success:function (response)
                        {   
                           window.location.href="<?php //echo base_url();?>claim";
                      }
                    });
        }
         $('body').on('click','.pending',function(e){
                  var id = $(this).data('id');
                  var st = $(this).data('status');
              
                  var dialog = bootbox.dialog({
                  title: 'Confirmation',
                  message: "<h4>Are you sure to approve or resubmit ?</h4>",
                  size: 'small',
                  buttons: {
                      cancel: {
                          label: "No action",
                          className: 'btn-danger',
                          callback: function(){
                              dialog.modal('hide');
                          }
                      },
                      resubmit: {
                          label: "Resubmit",
                          className: 'btn-primary',
                          callback: function(){
                              //dialog.modal('hide');
                              bootbox.confirm({ 
                                  size: "small",
                                  message: "Are you sure to resubmit?", 
                                  callback: function(result){ 
                                       
                                       var sts = 2;
                                       if(result){ update_status(id,sts); }
                                       
                                  }
                                });
                          }
                      },
                     
                      approve: {
                          label: "approve",
                          className: 'btn-success',
                          callback: function(){
                               bootbox.confirm({ 
                                  size: "small",
                                  message: "Are you sure to approve?", 
                                  callback: function(result){ 
                                    
                                       var sts = 1;
                                       if(result){ update_status(id,sts); }
                                       
                                  }
                                });
                            
                          }
                      }
                   }
                  });
            });

            $('body').on('click','.resubmit',function(e){
                  var id = $(this).data('id');
                  var st = $(this).data('status');
                  var msg = "You want to Approve ?";
                
                  var dialog = bootbox.dialog({
                  title: 'Confirmation',
                  message: "<h4>Sure,"+msg+"</h4>",
                  size: 'small',
                  buttons: {
                      cancel: {
                          label: "Cancel",
                          className: 'btn-danger',
                          callback: function(){
                              dialog.modal('hide');
                          }
                      },
                     
                      ok: {
                          label: "OK",
                          className: 'btn-info',
                          callback: function(){
                            var sts = 1;
                            update_status(id,sts);
                            
                          }
                      }
                   }
                  });
            }); */

          $('body').on('change','#chooseFile',function(e){
            var ext = $('#chooseFile').val().split('.').pop().toLowerCase();
            var filename = $("#chooseFile").val();
              if (/^\s*$/.test(filename)) {
                $(".file-upload").removeClass('active');
                $("#noFile").text("No file chosen..."); 
                 $('#uploadBtn').prop('disabled',true);
                $('#uploadBtn').attr('disabled',true);
              }else {
                $(".file-upload").addClass('active');
                $("#noFile").text(filename.replace("C:\\fakepath\\", ""));
               if(ext=="xlsx"){
                     $('#uploadBtn').prop('disabled',false);
                     $('#uploadBtn').attr('disabled',false);
                  }else{
                     $('#uploadBtn').prop('disabled',true);
                     $('#uploadBtn').attr('disabled',true);
                     $('#ImportClaimForm')[0].reset();
                     alert(ext+" File type not allowed");
                  }
               }
          });
          $('body').on('click','#uploadBtn',function(e){
             $('#ImportClaimForm').submit();
          });
            $(".allownumericwithdecimal").on("keypress keyup blur",function (event) {
               $(this).val($(this).val().replace(/[^0-9\.]/g,''));
                if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
                event.preventDefault();
             }
          }); 
         $('body').on('click','.downloadfile',function(e){
               window.location.href="<?php echo base_url();?>claim/downloadfile";
            });
            
            
          
       </script>
       <!-- Primary modal -->
          <div id="modal_ajax" class="modal fade">
            <div class="modal-dialog">
              <div class="modal-content">
                    <form class="modelForm" action="#" method="POST">
                <div class="modal-header bg-primary">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h6 class="modal-title"><span id="modaltitle">Primary header</span></h6>
                </div>

                <div class="modal-body">
                                                                    
                </div>

                <div class="modal-footer">
<!--                  <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary">Save changes</button>-->
                </div>
                   </form>
              </div>
            </div>
          </div>
<!-- /primary modal -->
     
    
            
        <!-- /theme JS files -->
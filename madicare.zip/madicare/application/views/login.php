<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.interface.club/limitless/layout_1/LTR/default/login_simple.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jan 2018 12:28:28 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Clinic</title>

	<!-- Global stylesheets -->
	<link href="?php echo base_url();?>assets/css/css1381.css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url();?>assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url();?>assets/css/core.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url();?>assets/css/components.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url();?>assets/css/colors.css" rel="stylesheet" type="text/css">
	<!-- /global stylesheets -->
        <style>
            .error{
                color:red;
            }
        </style>
	<!-- Core JS files -->
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/loaders/pace.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/core/libraries/jquery.min.js"></script>
         <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/validation/jquery.validate.min.js"></script>
         <script type="text/javascript">var base_url='<?php echo base_url();?>';</script>
         <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/validation/validated.js"></script> 
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/core/libraries/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/loaders/blockui.min.js"></script>
	<!-- /core JS files -->


	<!-- Theme JS files -->
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/core/app.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/velocity/velocity.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/velocity/velocity.ui.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/buttons/spin.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/buttons/ladda.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/pages/components_buttons.js"></script>
	<!-- /theme JS files -->

</head>

<body class="login-container">



	<!-- Page container -->
	<div class="page-container">

		<!-- Page content -->
		<div class="page-content">

			<!-- Main content -->
			<div class="content-wrapper">

				<!-- Content area -->
				<div class="content">

					<!-- Simple login form -->
					<form action="#" method="POST" id="LoginForm">
						<div class="panel panel-body login-form">
							<div class="text-center">
								<div class="icon-object border-slate-300 text-slate-300"><i class="icon-reading"></i></div>
								<h5 class="content-group">Login to your account <small class="display-block">Enter your credentials below</small></h5>
							</div>
                                                       <div class="ajax_response"></div>
							<div class="form-group has-feedback has-feedback-left">
								<input type="text" name="username" id="username" class="form-control" placeholder="Username">
								
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input type="password"  name="password" id="password" class="form-control" placeholder="Password">
								
							</div>

							<div class="form-group">
                                                                
								<button type="submit" class="btn btn-primary btn-block btn-ladda btn-ladda-progress" data-style="fade"><span class="ladda-label">Sign in <i class="icon-circle-right2 position-right"></i></span></button>
							</div>

							<div class="text-center">
								<a href="login_password_recover.html">Forgot password?</a>
							</div>
						</div>
					</form>
					<!-- /simple login form -->


					<!-- Footer -->
					<!-- <div class="footer text-muted text-center">
						&copy; 2018. <a href="#">The Real Builder construction </a> by <a href=".#" target="_blank">RRG SOFTWARE</a>
					</div> -->
					<!-- /footer -->

				</div>
				<!-- /content area -->

			</div>
			<!-- /main content -->

		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->

</body>

<!-- Mirrored from demo.interface.club/limitless/layout_1/LTR/default/login_simple.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jan 2018 12:28:28 GMT -->
</html>

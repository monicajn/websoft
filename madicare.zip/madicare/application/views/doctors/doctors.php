<!-- Content area -->
<div class="content">
 <div class="container-detached">
    <div class="content-detached">
      <div class="panel panel-flat">
        <div class="panel-body">
          <div class="row">
              	<!-- Start add new ctegory-->
            <div class="row">
                <div class="col-md-12">
                  <div class="panel panel-flat">
                        <div class="panel-heading">
                                <h6 class="panel-title"><?php echo $subtitle;?></h6>
                                <div class="heading-elements">
                                        <ul class="icons-list">

                                        </ul>
                                  </div>
                        </div>

                        <div class="panel-body">
                            <?php if($this->CI->checkPermission('dr_1')){ ?>
                            <form action="#" id="AddDoctorForm" method="POST" enctype="multipart/form-data">
                                <div class="row">
                                  <div class="col-md-2"></div>
                                   <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Doctor Name<span style="color:red;">*</span></label>
                                            <input type="text" name="name" id="name" class="form-control" placeholder="Enter Doctor name" required="">
                                         </div>
                                    </div>
                                    <div class="col-md-2">
                                         <button style="margin: 26px 0 0 0;" class="btn btn-success" type="submit" name="save" id="save" >SAVE</button>
                                      </div>
                                  </div>      
                             </form>
                             <?php } ?>
                            <div class="row">
                                <div class="table-responsive">                               
                                    <table id="example" class="table table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                                <tr>
                                                  <th>Doctors Name</th>
                                                  <th>Action</th>
                                                </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=1;foreach($doctors as $row) { ?>
                                                <tr>
                                                    <td><?php echo $row['name'];?></td>
                                                     <td class="text-center">
                                                          <?php if($this->CI->checkPermission('dr_2')){ ?>
                                                            <button type="button" class="btn btn-primary btn-icon" onclick="showmodel('<?php echo base_url("doctors/popup/editdoctors/".$row['id']);?>','Update  -(<?php echo $row['name'];?>)','TRUE','EditDoctorsForm','doctors/edit');"><i class="fa fa-edit"></i></button>
                                                            <?php } ?>
                                                           <?php if($this->CI->checkPermission('dr_3')){ ?>
                                                            <button type="button" class="btn btn-danger btn-icon delete" data-id="<?php echo $row['id'];?>"><i class="fa fa-trash"></i></button>
                                                            <?php } ?>
                                                      </td>
                                                 </tr>
                                            <?php $i++;} ?>   
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                         </div>
                      </div>
                    </div>
                </div>
                 <!-- End add new Produt-->
                 
               
          </div> 
       </div>
      </div>
    </div>
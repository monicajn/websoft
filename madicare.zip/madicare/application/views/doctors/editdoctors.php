<?php  $Data = $this->Doctors_model->getResult(array('*'),array('id'=>$param2));?>
<input type="hidden" name="id" value="<?php echo $param2;?>"/>
<div class="row">
    <div class="col-md-12"><!-- col6 2nd start-->
         <div class="form-group">
            
            <div class="row">
              <div class="col-sm-12">
                        <label>Docotor Name</label>
                        <input required name="ename" id="ename" type="text" placeholder="Enter Docotor name" class="form-control" value="<?php echo $Data[0]['name'];?>">
                </div>
            </div>
         </div>
        
         
     </div><!-- col6 2nd end-->  
     
  </div> 

<?php  $join=array('states'=>'states.id=user.state_id','cities'=>'cities.id=user.city_id');
$udata = $this->User_model->getResult(array('states.name AS state','cities.name AS city','user.*'),array('user.id'=>$param2),$join);?>

<div class="row">
    <div class="col-md-12" id="errormsg"></div>
</div>
<div class="row">
    <div class="col-md-12">
       <div class="table-responsive content-group">
         <table class="table table-bordered table-striped">
              <thead>
                          
                            <tr>
                                <th >User-ID</th>
                                 <td> <?php  echo $udata[0]['userID'] ;?></td>
                              </tr>
                               <tr>
                                  <th >Username</th>
                                    <td> <?php  echo $udata[0]['username'] ;?></td>
                              </tr>
                               <tr>
                                   <th >Name</th>
                                    <td> <?php  echo $udata[0]['fname']." ".$udata[0]['mname']." ".$udata[0]['lname'] ;?></td>
                              </tr>
                               <tr>
                                   <th >DOB</th>
                                    <td> <?php if($udata[0]['dob']!=''){ echo $this->CI->createFormatDate($udata[0]['dob'],'Y-m-d','m/d/Y');}?></td>
                              </tr>
                               <tr>
                                   <th >Email</th>
                                    <td> <?php  echo $udata[0]['email'] ;?></td>
                              </tr>
                              <tr>
                                   <th >Mobile No</th>
                                    <td> <?php  echo $udata[0]['mobile'] ;?></td>
                              </tr>
                              <tr>
                                 <th>State</th>
                                 <td> <?php  echo $udata[0]['state'] ;?></td>
                                 </tr>
                              <tr>
                                 <th>City</th>
                                 <td> <?php  echo $udata[0]['city'] ;?></td>
                              </tr>
                               <tr>
                                 <th>Address</th>
                                 <td> <?php  echo $udata[0]['address'] ;?></td>
                              </tr>
                              
                    </thead>
                    <tbody>
                        
                           
                    </tbody>
                    
            </table>
        </div>
    </div>
</div>


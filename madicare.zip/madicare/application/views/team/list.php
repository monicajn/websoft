<!-- Content area -->
				<div class="content">
					
                                        	 <!-- Start builder list -->
					<div class="panel panel-flat">
						<div class="panel-heading">
							<h5 class="panel-title"><?php echo $subtitle;?></h5>
                              <div class="heading-elements">
								<ul class="icons-list">
									 <?php if($this->CI->checkPermission('tm_1')){ ?>
                                      <li><a href="#"  data-src="team/add" class="btn btn-success redirect"><i class="icon-plus3"></i>&nbsp;New Member</a></li>
                                      <?php } ?>
                                </ul>
		                      </div>
							
						</div>

						<div class="panel-body">
                             <div class="table-responsive">                               
                              <table id="example" class="table table-bordered" cellspacing="0" width="100%"> 
									<thead>
								        <tr>
								            <th>UserID</th>
								            <th>Name</th>
								            <th>Email</th>
								            <th>username</th>
								            <th>User Type</th>
								            <th>Mobile</th>
								            <th>DOB</th>
								            <th>City </th>
								            <th>State</th>
		                                    <th>Action</th>
								        </tr>
								    </thead>
								    <tbody>
								    	<?php foreach ($users as $row ) {
								    	   if($row['id']!=$this->login['id']) { ?>
								    		<tr>
		                                 	<td><b><a href="#"><?php echo $row['userID'];?></a></b></td>
								            <td><?php echo $row['fname']." ".$row['mname']." ".$row['lname'];?></td>
								            <td><?php echo $row['email'];?></td>
								            <td><?php echo $row['username'];?></td>
								            <td class="text-center"><b><?php echo $row['type'];?></b></td>
								            <td><?php echo $row['mobile'];?></td>
								            <td><?php echo $row['dob'];?></td>
								            <td><?php echo $row['city'];?></td>
		                                    <td><?php echo $row['state'];?></td>
							                <td >
							                	<?php ?>
							                <?php if($this->CI->checkPermission('tm_4')){ ?>
								            	 <a href="#" class="btn btn-primary btn-xs view" data-id="<?php echo $row['id'];?>" onclick="showmodel('<?php echo base_url("team/popup/viewuser/".$row['id']);?>','User Details  -(<?php echo $row['userID'];?>)','FALSE','','');" ><i class="fa fa-eye" ></i></a>
										          <?php } ?>
										      <?php if($this->CI->checkPermission('tm_2')){ ?>
										          <a href="#"  data-src="team/edit/<?php echo $row['id'];?>"  class="btn btn-info btn-xs redirect" data-id="<?php echo $row['id'];?>" ><i class="fa fa-edit"></i></a>
										       <?php } ?>
										       <?php if($this->CI->checkPermission('tm_2')){ ?>
										          <a href="#" class="btn <?php if($row['status']==0){ echo 'btn-warning';}else{ echo 'btn-success ';}?> btn-xs changest" data-id="<?php echo $row['id'];?>" data-status="<?php echo $row['status'];?>"><?php if($row['status']==0){ echo 'Inactive';}else{ echo 'Active';}?></a>
										        <?php } ?>
										        <?php if($this->CI->checkPermission('tm_3')){ ?>
										          <a class="btn btn-danger btn-xs delete" data-id="<?php echo $row['id'];?>"><i class="fa fa-trash"></i></a>
										        <?php } ?>
										        
									       </td>
								        </tr>           
								       <?php }  }?>
								    </tbody>
								</table>
							</div>
						</div>
					</div>
                                                <!-- end builder list -->
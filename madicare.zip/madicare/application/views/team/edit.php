<!-- Content area -->
				<div class="content">
					<!-- Start add new builder-->
					<div class="row">
          <div class="col-md-12">
              <div class="panel panel-flat">
                      <div class="panel-heading">
                              <h6 class="panel-title"><?php echo $subtitle;?></h6>
                              <div class="heading-elements">
                                      <ul class="icons-list">
                                        <li><a href="#" data-src="team" class="btn btn-default redirect"><i class="icon-undo2"></i>&nbsp;Back to Tam List</a></li>
                                    </ul>
                             </div>
                      </div>

                  <div class="panel-body">
                    <form action="#" id="EditTeamForm" method="POST">
                          <div class="row">
                              <div class="col-md-4">
                                  <div class="form-group">
                                      <label>First Name<span style="color:red;">*</span></label>
                                      <input type="text" name="fname" id="fname" class="form-control" placeholder="Enter First Name" value="<?php echo $userdata['fname'];?>">
                                   </div>
                                  </div>

                                  <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Middle Name</label>
                                            <input type="text" name="mname" id="mname" class="form-control" placeholder="Enter Middle Name" value="<?php echo $userdata['mname'];?>">
                                           </div>
                                  </div>
                                  <div class="col-md-4">
                                     <div class="form-group">
                                        <label>Last Name<span style="color:red;">*</span></label>
                                            <input type="text" name="lname" id="lname" class="form-control" placeholder="Enter Last Name" value="<?php echo $userdata['lname'];?>">
                                      </div>
                                  </div>    
                          </div>

                                                                                 
                         <div class="row">
                             <div class="col-md-4">
                                  <div class="form-group">
                                        <label>DOB</label>
                                        <input type="text" name="dob" id="dob" class="form-control datepicker" placeholder="select DOB(dd/mm/yy)" value="<?php echo $this->CI->createFormatDate($userdata['dob'],'Y-m-d','m/d/Y')?>">
                                   </div>
                                  </div>
                              <div class="col-md-4">
                                   <div class="form-group">
                                        <label>Email</label>
                                         <input type="text" name="email" id="email" class="form-control" placeholder="Enter  Email" value="<?php echo $userdata['email'];?>">
                                   </div>
                                  </div>

                                  
                                  <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Mobile No</label>
                                            <input type="text" name="mobile" id="mobile" class="form-control mobilemask" placeholder="Enter Mobile No" value="<?php echo $userdata['mobile'];?>">
                                           </div>
                                  </div>

                              </div>

                              <div class="row">
                              
                                  <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Username</label>
                                            <input type="text" name="username" id="username" class="form-control" placeholder="Enter username" value="<?php echo $userdata['username'];?>">
                                           </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="form-group">
                                        <label>State</label>
                                           <select name="state_id" id="state_id" style="width: 100%;" class="select2"  >
                                             <option value="">-select-</option>
                                             <?php foreach($states as $row){?>
                                               <option value="<?php echo $row['id'];?>" 
                                                <?php if($row['id']==$userdata['state_id']){echo "selected";}?>><?php echo $row['name'];?></option>
                                               <?php } ?>
                                           </select>
                                     </div>
                                  </div>

                                  <div class="col-md-3">
                                    <div class="form-group">
                                        <label>City</label>
                                                <select name="city_id" id="city_id" style="width: 100%;" class="select2"  >
                                                <option value="">-select-</option>
                                                <?php foreach($cities as $row){?>
                                                  <option value="<?php echo $row['id'];?>" <?php if($row['id']==$userdata['city_id']){echo "selected";}?>><?php echo $row['name'];?></option>
                                               <?php } ?>
                                       </select>
                                     </div>
                                  </div>
                                  <div class="col-md-1">
                                           <button  type="button" class="btn btn-info" style="margin:25px 0 0 0;"  onclick="showmodel('<?php echo base_url("crud/citypopup/addcity/".$row['id']);?>','ADD CITY','TRUE','AddcityForm','crud/addcity');"><i class="fa fa-plus"></i></button>
                                  </div>
                                  
                          </div>
                         
                          <div class="row">
                                 
                                  <div class="col-md-4">
                                          <div class="form-group">
                                             <label> Zipcode</label>
                                             <input type="text" name="zipcode" id="zipcode" class="form-control" placeholder="Enter Zipcode" value="<?php echo $userdata['zipcode'];?>">
                                            </div>
                                  </div>
                                  <div class="col-md-4">
                                          <div class="form-group">
                                             <label> Address</label>
                                             <input type="text" name="address" id="address" class="form-control" placeholder="Enter Address" value="<?php echo $userdata['address'];?>">
                                              <input type="hidden" name="id" id="id" value="<?php echo $userdata['id'];?>">
                                           </div>
                                  </div>
                          </div>
                          <?php if($userdata['access']!=''){ $access = explode(',', $userdata['access']);}else{ $access = array(); }  ?>
                          <div class="row">
                              <div class="panel panel-default border-grey">
                                  <div class="panel-heading">
                                     <h6 class="panel-title">Select permission<a class="heading-elements-toggle"><i class="icon-more"></i></a></h6>
                                      <div class="heading-elements">
                                        <ul class="icons-list">
                                             <li><a data-action="reload"></a></li>
                                         </ul>
                                       </div>
                                   </div>
                                    <div class="panel-body">
                                      <div class="table-responsive">   
                                        <table  class="table table-bordered" cellspacing="0" width="100%"> 
                                          <thead>
                                            <tr>
                                              <th>SNO</th>
                                              <th>Module</th>
                                              <th colspan="4">Access Permission</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                               <?php $p =1;foreach ($modules as $row) { ?>
                                              
                                            <tr>
                                              <td><?php echo $p;?>.</td>
                                              <td>
                                               <label>
                                                  <input type="checkbox" class="styled parentclass" name="<?php echo $row['code'];?>" id="<?php echo $row['code'];?>"  value="<?php echo $row['code'];?>" <?php if(in_array($row['code'],$access)){ echo "checked";} ?>>
                                                   <?php echo $row['module'];?>
                                                </label>
                                              
                                            </td>
                                            <?php $childs = $this->Module_model->getResult(array('*'),array('parent_id'=>$row['id']));
                                            $c=1;foreach ($childs as $ch) { ?>
                                              <td>
                                                 <label class="<?php echo $row['code'];?>">
                                                    <input type="checkbox" class="styled <?php echo $ch['code'];?> <?php echo $row['code']."_ch";?>"  value="<?php echo $ch['code'];?>" name="<?php echo $ch['code'];?>"  <?php if(!in_array($row['code'],$access)){ echo "disabled";} ?> <?php if(in_array($ch['code'],$access)){ echo "checked";} ?>>
                                                     <?php echo $ch['module'];?>
                                                  </label>
                                                
                                            </td>
                                              <?php $c++;} ?>
                                            </tr>
                                      <?php $p++;} ?>
                                          </tbody>
                                        </table>
                                    </div>
                                </div>
                          </div>
                         <div class="text-right">
                           <button type="submit" name="save" class="btn btn-primary">Submit <i class="icon-arrow-right14 position-right"></i></button>
				                 </div>
			                </form>
							    </div>
							</div>
						</div>
					</div>
                                        
         
					<!-- End add new builder-->
                                        	 
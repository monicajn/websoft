 <?php $claim = $this->Claim_model->getResult(array('balance','total_invoice'),array('id'=>$param2));
 $totalrec = $this->Payment_model->getResult(array('SUM(amount) as trec'),array('claim_id'=>$param2)); ?>
 <input  name="claim_id" id="claim_id" type="hidden"   value="<?php echo $param2;?>">
  <input  name="total_invoice" id="total_invoice" type="hidden"   value="<?php echo $claim[0]['total_invoice'];?>">
  <input  name="balance" id="balance" type="hidden"   value="<?php echo $claim[0]['balance'];?>">
  <input  name="total_rec" id="total_rec" type="hidden"   value="<?php echo $totalrec[0]['trec'];?>">
  
<div class="row">
    <div class="col-md-12"><!-- col6 2nd start-->
         <div class="form-group">
            <div class="row">
                <div class="col-sm-6">
                        <label>Amount</label>
                        <input required name="amount" id="amount" type="text" placeholder="Enter Amount Received" class="form-control" value="0">
                </div>
                  <div class="col-sm-6">
                        <label>Received BY</label>
                        <select name="paid_by" id="paid_by" style="width: 100%;" class="form-control" >
                                <option value="">-select-</option>
                                <option value="claim">Claim</option>
                                <option value="patient">-Patient-</option>
                                
                          </select>
                </div>
                
            </div>
            
         </div>
        
         
     </div><!-- col6 2nd end-->  
  </div> 
  <script type="text/javascript">
    $("#AddPaymentForm").validate({
            rules:{
               'amount':{
                     required: true,
                     minStrict:0,
                        },
                'paid_by':{
                    required:true
                        }
            },

            messages:{
                'amount':{
                       required: "Please Enter Amount",
                       minStrict: "Should be grater then 0"
                        },
                'paid_by':{
                    required:"Select received By"
                        }

            }

});
  </script>
 
<!-- Content area -->
				<div class="content">
					
                                        	 <!-- Start builder list -->
					<div class="panel panel-flat">
						<div class="panel-heading">
							<h5 class="panel-title"><?php echo $subtitle;?></h5>
							 <div class="row">
                                <form id="searchForm" method="POST" >
                                    <div class="col-md-2">
                                      <div class="form-group">
                                        <label>Date:</label>
                                       <input type="text" name="date" id="date" class="form-control datepicker" readonly="" value="<?php if(isset($_POST['search'])){ echo $_POST['date'];}?>">
                                       </div>
                                   </div>
                                   <div class="col-md-2">
                                     <div class="form-group">
                                        <label>Date of service:</label>
                                       <input type="text" name="dos" id="dos" class="form-control datepicker" readonly="" value="<?php if(isset($_POST['search'])){ echo $_POST['dos'];}?>">
                                      </div>
                                    </div> 
                                    <div class="col-md-2">
                                    	 <label>Status:</label>
	                                    <select name="status" id="status" class="form-control">
	                                    	<option value="all" <?php if(isset($_POST['search'])){ if($_POST['status']=='all'){ echo "selected";}}?>>select</option>
	                                    	<option value="0" <?php if(isset($_POST['search'])){ if($_POST['status']=='0'){ echo "selected";}}?>>pending</option>
		                             		<option value="1" <?php if(isset($_POST['search'])){ if($_POST['status']=='1'){ echo "selected";}}?>>submitted</option>
		                             		<option value="2" <?php if(isset($_POST['search'])){ if($_POST['status']=='2'){ echo "selected";}}?>>approved</option>
		                             		<option value="3" <?php if(isset($_POST['search'])){ if($_POST['status']=='3'){ echo "selected";}}?>>Re-submitted</option>
		                             		<option value="4" <?php if(isset($_POST['search'])){ if($_POST['status']=='4'){ echo "selected";}}?>>denied</option>
		                             		<option value="5" <?php if(isset($_POST['search'])){ if($_POST['status']=='5'){ echo "selected";}}?>>deposited</option>
		                             		
	                             	   </select>
                                    </div>
                                    <div class="col-md-2">
                                    	 <label>Month:</label>
	                                      <select name="month" id="month" style="width: 100%;" class="form-control"  >
                                                 <option value="all" <?php if(isset($_POST['search'])){ if($_POST['month']=='all'){ echo "selected";}}?>>-select-</option>
                                                      <?php foreach ($this->_month as $key => $value) { ?>
                                                            <option value="<?php echo $key;?>" <?php if(isset($_POST['search'])){ if($_POST['month']==$key){ echo "selected";}}?>><?php echo $value;?></option>
                                                  <?php } ?>
                                                       
                                               </select>
                                    </div>
                                   <div class="col-md-1">
                                       <button style="margin-top: 26px;" type="submit" name="search" class="btn btn-success"><i class="fa fa-search"></i>&nbsp;Search</button>
                                   </div>
                                    <div class="col-md-1">
                                       <a style="margin-top: 26px;" href="<?php echo base_url();?>claim" class="btn btn-default"><i class="fa fa-refresh"></i>&nbsp;reset</a>
                                   </div>

                                </form>
                           </div>
                              <div class="heading-elements">
								<ul class="icons-list">
									 <?php if($this->CI->checkPermission('cl_1')){ ?>
                                      <li><a href="#" data-src="claim/add" class="btn btn-success redirect"><i class="icon-plus3"></i>&nbsp;New Claim</a></li>
                                     <?php } ?>
                                </ul>
		                      </div>
							
						</div>

						<div class="panel-body">
							<form method="POST" id="actionForm" action="<?php echo base_url();?>claim/updateBulkstatus">
                             <div class="table-responsive">   
                                               
                              <table id="example" class="table table-bordered" cellspacing="0" width="100%"> 
									<thead>
								        <tr>
								        <?php if($this->CI->checkPermission('cl_2')){ ?>	
								        	<th><label class="checkbox-inline">
                                               <input type="checkbox" name="checkAll" id="checkAll" class="styled checkAll" value="All">
                                            </label></th>
                                          <?php } ?>
								            <th>Date</th>
								            <th>Date of Service</th>
								            <th>Month</th>
								            <th>Patient Name</th>
								            <th>Insurance </th>
								            <th>CPT Code</th>
		                                    <th>Qty</th>
								            <th>Rate</th>
								            <th>Received</th>
								            <th>Balance</th>
								            <th>Status</th>
								        </tr>
								    </thead>
								    <tbody>
		                                <?php foreach ($claims as $row ) { ?>
		               <?php  if($row['date']!=''){ $date = $this->CI->createFormatDate($row['date_of_service'],'Y-m-d','m/d/Y');}else{$date='';}?>
		       <?php  if($row['date_of_service']!=''){ $dos = $this->CI->createFormatDate($row['date_of_service'],'Y-m-d','m/d/Y');}else{$dos='';}?>
								    		<tr>
								    	<?php if($this->CI->checkPermission('cl_2')){ ?>	
								    		<td class="text-center">
								    		   <label class="checkbox-inline tdinline">
                                                  <input type="checkbox" name="ids[]" class="styled tdcheck" value="<?php echo $row['id'];?>">
                                              </label>
								    		</td>
								    	<?php } ?>
		                                 	<td><b><a href="#" onclick="showmodel('<?php echo base_url("claim/popup/viewclaim/".$row['id']);?>','Claim Details  -(<?php echo $row['pfname']." ".$row['plname'];?>)','FALSE','','');"><?php echo $date;?></a></b></td>
		      
								            <td><?php echo $dos;?></td>
								            <td><?php if($row['month']!=''){ echo $this->_month[$row['month']];}?></td>
								            <td><?php echo $row['pfname']." ".$row['plname'];?></td>
								            <td><?php echo $row['insurancename'];?></td>
		                                    <td><?php echo $row['code'];?></td>
							                <td><?php echo $row['quantity'];?></td>
							                 <td><?php echo $row['rate'];?></td>
							                 <td><?php echo $row['amount_received'];?></td>
							                  <td><?php echo $row['balance'];?></td>
								             <td class="text-right">
								             	<?php if($row['status']==0){ $class =" label-warning pending";$text="Pending";}  
								             	        else if($row['status']==1){ $class ="label-default submitted";$text="Submitted";}
								             	        else if($row['status']==2){ $class ="label-success approved";$text="Approved";}
								             	        else if($row['status']==3){ $class ="label-primary resubmit";$text="Resubmit";}
								             	        else if($row['status']==4){ $class ="label-danger denied";$text="Denied";}
								             	        else if($row['status']==5){ $class ="label-info deposited";$text="Deposited";}
								             	         ?>
                                               <p class="label <?php echo $class;?>"><?php echo $text;?></p>
										      <?php /* <a href="#" class="btn btn-xs <?php echo $class;?>" data-id="<?php echo $row['id'];?>" data-status="<?php echo $row['status'];?>"><?php echo $text;?></a> */?>
										       <?php if($this->CI->checkPermission('cl_4')){ ?>
										         <p style="cursor: pointer;background-color: #90239d;" class="label label-info view redirect" data-id="<?php echo $row['id'];?>" data-src="claim/viewclaim/<?php echo $row['id'];?>"><i class="fa fa-eye"></i>&nbsp;view</p>
										        <?php } ?>
										        <?php if($this->CI->checkPermission('cl_2')){ ?>
										         <p style="cursor: pointer;background-color: #3a8a78;" class="label label-info view redirect" data-id="<?php echo $row['id'];?>" data-src="claim/edit/<?php echo $row['id'];?>"><i class="fa fa-edit"></i>&nbsp;Edit</p>
										        <?php } ?>
										        <?php if($this->CI->checkPermission('cl_3')){ ?>
										         <p style="cursor: pointer;" class="label label-danger delete" data-id="<?php echo $row['id'];?>"><i class="fa fa-trash"></i>&nbsp;delete</p>
										        <?php } ?>
									       </td>
								        </tr>            
								       <?php } ?> 
                                                 
								       
								    </tbody>
								</table>
							</div>
							<?php if($this->CI->checkPermission('cl_2')){ ?>
							<div class="row">
                             	<div class="col-md-3">
                             	<select name="action" id="action" class="form-control">
                             		<option value="0">pending</option>
                             		<option value="1">submitted</option>
                             		<option value="2">approved</option>
                             		<option value="3">Re-submitted</option>
                             		<option value="4">denied</option>
                             		<option value="5">deposited</option>
                             	</select>
                             	</div>
                             	 <div class="col-md-2"><button type="button" name="go" id="go" class="btn btn-success">action</button> </div>
                             </div> 
                            <?php } ?>       
						</form>
						</div>
					</div><!--0: pending, 1: approve 2: resubmitt-->
                                                <!-- end builder list -->
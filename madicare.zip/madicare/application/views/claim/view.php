<!-- Content area -->
				<div class="content">
					<!-- Start add new builder-->
					<div class="row">
              <div class="col-md-12">
				         <div class="panel panel-flat">
                    <div class="panel-heading">
                        <h6 class="panel-title"><?php echo $subtitle;?></h6>
                          <div class="heading-elements">
                                  <ul class="icons-list">
                                     <li><a href="#" data-src="claim" class="btn btn-default redirect"><i class="icon-undo2"></i>&nbsp;Back to Claim List</a></li>
                                     <?php if($this->CI->checkPermission('cl_2')){ ?>
                                     <li><a href="#" class="btn btn-info redirect" data-src="claim/edit/<?php echo $claimdata['id'];?>"><i class="fa fa-edit"></i>&nbsp;Edit Claim</a></li>
                                     <?php } ?>
                                     <?php if($this->CI->checkPermission('cl_1')){ ?>
                                     <li><a href="#" class="btn btn-success" onclick="showmodel('<?php echo base_url("claim/popup/addpayment/".$claimdata['id']);?>','ADD Received Payment','TRUE','AddPaymentForm','claim/addpayment');"><i class="fa fa-plus"></i>&nbsp;ADD Payment</a></li>
                                     <?php } ?>
                                  </ul>
                            </div>
                      </div>
				              <div class="panel-body">
                        <div class="row">
                          <div class="table-responsive">
                            <table class="table table-bordered" cellspacing="0" width="100%">
                              <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Date Of service</th>
                                    <th>Transaction Type</th>
                                    <th>Patient Name</th>
                                    <th>Month</th>
                                    <th>Insurance</th>
                                    <th>CPTCODE</th>
                                    <th>Discription</th>
                                    <th>Quantity</th>
                                    <th>Rate</th>
                                </tr>
                                 <tr>
                                    
                              <td><?php echo $claimdata['date'];?></td>
                              <td><?php echo $claimdata['date_of_service'];?></td>
                              <td><?php echo $claimdata['transaction_type'];?></td>
                              <td><?php echo $claimdata['pfname']." ".$claimdata['plname'];?></td>
                              <td><?php if($claimdata['month']!=''){ echo $this->_month[$claimdata['month']];}?></td>
                              <td><?php echo $claimdata['insurancename'];?></td>
                              <td><?php echo $claimdata['code'];?></td>
                              <td><?php echo $claimdata['description'];?></td>
                              <td><?php echo $claimdata['quantity'];?></td>
                              <td><?php echo $claimdata['rate'];?></td>
                             </tr>
                              </thead>
                            </table>
                          </div>
                          
                        </div>

                               <div class="row">
                                  <div class="panel panel-default border-grey">
                                      <div class="panel-heading">
                                         <h6 class="panel-title">Transaction Details<a class="heading-elements-toggle"><i class="icon-more"></i></a></h6>
                                          <div class="heading-elements">
                                            <ul class="icons-list">
                                                 <li><a data-action="reload"></a></li>
                                             </ul>
                                           </div>
                                       </div>
                                        <div class="panel-body">
                                          <div class="table-responsive">   
                                            <table  class="table table-bordered" cellspacing="0" width="100%"> 
                                              <thead>
                                                <tr>
                                                  <th>SNO</th>
                                                  <th>Date</th>
                                                  <th>Received BY</th>
                                                  <th>Amount</th>
                                                  <th>Action</th>
                                                </tr>
                                              </thead>
                                              <tbody>
                                                <?php $pdatas = $this->Payment_model->getResult(array(),array('claim_id'=>$claimdata['id']));
                                                $p=1;$received=0;
                                                foreach ($pdatas as $row) { $received +=$row['amount']; ?>
                                                  
                                                <tr>
                                                  <td><?php echo $p;?></td>
                                                  <td><?php echo $this->CI->format_date($row['date_time'],'Y-m-d');?></td>
                                                  <td><?php echo $row['paid_by'];?></td>
                                                  <td class="text-right"><b><?php echo $row['amount'];?></b></td>
                                                  <td>-</td>
                                                </tr>
                                                <?php $p++;}  ?>
                                              </tbody>
                                              <tr>
                                                <th class="text-right" colspan="3">Total Invoice</th>
                                                <th class="text-right"><?php echo $claimdata['total_invoice'];?></th>
                                                <th></th>
                                              </tr>
                                               <tr>
                                                <th class="text-right" colspan="3">Total Received</th>
                                                <th class="text-right text-success"><?php echo $received;?></th>
                                                <th></th>
                                              </tr>
                                               <tr>
                                                <th class="text-right" colspan="3">Balance</th>
                                                <th class="text-right text-warning"><?php echo $claimdata['balance'];?></th>
                                                <th></th>
                                              </tr>
                                            </table>
                                          </div>
                                          
                                        </div>
                                      </div>
                                    </div>
							        </div>
							   </div>
						   </div>
					  </div>
                                        
         
					<!-- End add new builder-->
                                        	 
<?php  $join=array('cptcode'=>'cptcode.id=claims.cpt_code',
                   'patients'=>'patients.id=claims.patient_id',
                   'insurance'=>'insurance.id=claims.insurance');
$pdata = $this->Claim_model->getResult(array('tbl_patients.fname as pfname','tbl_patients.lname as plname','insurance.name AS insurancename','cptcode.code as code','claims.*'),array('claims.id'=>$param2),$join);
?>

<div class="row">
    <div class="col-md-12" id="errormsg"></div>
</div>
<div class="row">
    <div class="col-md-12">
       <div class="table-responsive content-group">
         <table class="table table-bordered table-striped">
              <thead>
                          
                            <tr>
                                <th >Date</th>
                                 <td> <?php  echo $pdata[0]['date'] ;?></td>
                              </tr>
                              
                               <tr>
                                   <th >Date of Service</th>
                                    <td> <?php  echo $pdata[0]['date_of_service'];?></td>
                              </tr>
                               <tr>
                                   <th >Transaction type</th>
                                    <td> <?php  echo $pdata[0]['transaction_type'] ;?></td>
                              </tr>
                              
                              <tr>
                                   <th >Patient</th>
                                    <td> <?php  echo $pdata[0]['pfname']." ".$pdata[0]['plname'] ;?></td>
                              </tr>
                               <tr>
                                   <th >Month</th>
                                    <td> <?php echo $this->_month[$pdata[0]['month']] ;?></td>
                              </tr>
                               <tr>
                                   <th >insurance</th>
                                    <td> <?php  echo $pdata[0]['insurancename'] ;?></td>
                              </tr>
                              <tr>
                                   <th >CPT Code</th>
                                    <td> <?php  echo $pdata[0]['code'] ;?></td>
                              </tr>
                              <tr>
                                 <th>Description</th>
                                 <td> <?php  echo $pdata[0]['description'] ;?></td>
                                 </tr>
                              <tr>
                                 <th>Qunatity</th>
                                 <td> <?php  echo $pdata[0]['quantity'] ;?></td>
                              </tr>
                               <tr>
                                 <th>Rate</th>
                                 <td> <?php  echo $pdata[0]['rate'] ;?></td>
                              </tr>
                              <tr>
                                 <th>Amount Received</th>
                                 <td> <?php  echo $pdata[0]['amount_received'] ;?></td>
                              </tr>
                              <tr>
                                 <th>Balance</th>
                                 <td> <?php  echo $pdata[0]['balance'] ;?></td>
                              </tr>
                              
                    </thead>
                    <tbody>
                        
                           
                    </tbody>
                    
            </table>
        </div>
    </div>
</div>


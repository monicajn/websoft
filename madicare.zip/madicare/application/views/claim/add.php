<!-- Content area -->
				<div class="content">
					<!-- Start add new builder-->
					<div class="row">
              <div class="col-md-12">
				         <div class="panel panel-flat">
                    <div class="panel-heading">
                        <h6 class="panel-title"><?php echo $subtitle;?></h6>
                          <div class="heading-elements">
                                  <ul class="icons-list">
                                     <li><a href="#" data-src="claim" class="btn btn-default redirect"><i class="icon-undo2"></i>&nbsp;Back to Claim List</a></li>
                                  </ul>
                            </div>
                      </div>

				              <div class="panel-body">
                        <form action="#" id="AddClaimForm" method="POST">
                              <div class="row">
                                  <div class="col-md-4">
                                      <div class="form-group">
                                          <label>Date<span style="color:red;">*</span></label>
                                          <input type="text" name="date" id="date" class="form-control datepicker" placeholder="Select Date" >
                                       </div>
                                      </div>

                                      <div class="col-md-4">
                                              <div class="form-group">
                                                <label>Transaction Type</label>
                                                   <select name="transaction_type" id="transaction_type" style="width: 100%;" class="select2">
                                                      <option value="">-select-</option>
                                                      <option value="claim">Claim</option>

                                                   </select>
                                               </div>
                                      </div>
                                      <div class="col-md-4">
                                         <div class="form-group">
                                            <label>Date of Service<span style="color:red;">*</span></label>
                                                <input type="text" name="date_of_service" id="date_of_service" class="form-control datepicker" placeholder="Select Date">
                                          </div>
                                      </div>    
                              </div>

                                                                                     
                             <div class="row">
                                   <div class="col-md-3">
                                      <div class="form-group">
                                            <label>Patient Name</label>
                                               <select name="patient_id" id="patient_id" style="width: 100%;" class="select2"  >
                                                      <option value="">-select-</option>
                                                       <?php foreach ($patients as $row) { ?>
                                                      <option value="<?php echo $row['id'];?>"><?php echo $row['fname']." ".$row['mname']." ".$row['lname'];?></option>
                                                      <?php } ?> 
                                               </select>
                                       </div>
                                      </div>

                                      <div class="col-md-3">
                                      <div class="form-group">
                                            <label>Doctors(Providers)</label>
                                               <select name="doctor_id" id="doctor_id" style="width: 100%;" class="select2"  >
                                                      <option value="">-select-</option>
                                                       <?php foreach ($doctors as $row) { ?>
                                                      <option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
                                                      <?php } ?> 
                                               </select>
                                       </div>
                                      </div>
                                   
                                     <div class="col-md-3">
                                      <div class="form-group">
                                            <label>Month</label>
                                               <select name="month" id="month" style="width: 100%;" class="select2"  >
                                                      <option value="">-select-</option>
                                                      <?php foreach ($this->_month as $key => $value) { ?>
                                                            <option value="<?php echo $key;?>"><?php echo $value;?></option>
                                                          <?php } ?>
                                                       
                                               </select>
                                       </div>
                                      </div>
                                     <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Insurance</label>
                                               <select name="insurance" id="insurance" style="width: 100%;" class="select2"  >
                                                    <option value="">-select-</option>
                                                    <?php foreach ($insurance as $row) { ?>
                                                        <option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
                                                   <?php }?>
                                               </select>
                                         </div>
                                      </div>

                                  </div>
                                    
                                  <div class="row">
                                      <div class="col-md-4">
                                              <div class="form-group">
                                                <label>CPT Code</label>
                                                <select name="cpt_code" id="cpt_code" style="width: 100%;" class="select2"  >
                                                    <option value="">-select-</option>
                                                    <?php foreach ($cpts as $row) { ?>
                                                        <option value="<?php echo $row['id'];?>"><?php echo $row['code'];?></option>
                                                   <?php }?>
                                               </select>
                                               </div>
                                      </div>
                                      <div class="col-md-4">
                                              <div class="form-group">
                                                <label>Desicription</label>
                                                <input type="text" name="description" id="description"  class="form-control" placeholder="Enter Desicription">
                                               </div>
                                      </div>
                                     
                                       <div class="col-md-2">
                                              <div class="form-group">
                                                <label>Quantity</label>
                                                <input type="text" name="quantity" id="quantity"  class="form-control calculate allownumericwithdecimal" placeholder="Enter Quantity" value="0">
                                               </div>
                                        </div>
                                         <div class="col-md-2">
                                                    <div class="form-group">
                                                      <label>Rate</label>
                                                      <input type="text" name="rate" id="rate" class="form-control calculate decimal allownumericwithdecimal" placeholder="Enter Rate" value="0">
                                                     </div>
                                          </div>

                                       
                                  </div>

                                    <div class="row">
                                          
                                        <div class="col-md-4">
                                              <div class="form-group">
                                                <label>Total Invoice amount</label>
                                                <input type="text" name="total_invoice" id="total_invoice"  class="form-control decimal calculate allownumericwithdecimal" placeholder="Enter Total Invoice amount" value="00.00" readonly="">
                                               </div>
                                      </div>
                                          <div class="col-md-2">

                                                    <div class="form-group">
                                                      <label>Paid by Patient</label>
                                                      <input type="text" name="by_pt" id="by_pt"  class="form-control decimal calculate allownumericwithdecimal" placeholder="Amount Received if any" value="0">
                                                     </div>
                                            </div>
                                            <div class="col-md-2">
                                              <span style="position: absolute;top: 36px;left: -4px;"><i class="fa fa-plus"></i></span>
                                                    <div class="form-group">
                                                      <label>Amount Received By Claim</label>
                                                      <input type="text" name="by_claim" id="by_claim"  class="form-control decimal calculate allownumericwithdecimal" placeholder="Amount Received if any" value="0">
                                                     </div>
                                            </div>
                                             <div class="col-md-2">
                                              <span style="position: absolute;top: 36px;left: -4px;"><i class="fa fa-map-signs"></i></span>
                                                    <div class="form-group">
                                                      <label>Total Received</label>
                                                      <input type="text" name="amount_received" id="amount_received"  class="form-control" placeholder="Amount Received if any" value="0" readonly="">
                                                     </div>
                                            </div>

                                             <div class="col-md-2">
                                                    <div class="form-group">
                                                      <label>Balance</label>
                                                      <input type="text" name="balance" id="balance"  class="form-control" placeholder="0" readonly="" value="0">
                                                     </div>
                                            </div>
                                    </div>
                                   <div class="text-right">
                                         <button type="submit" name="save" class="btn btn-primary">Submit <i class="icon-arrow-right14 position-right"></i></button>
				                         </div>
			                   </form>
							    </div>
							</div>
						</div>
					</div>
                                        
         
					<!-- End add new builder-->
                                        	 
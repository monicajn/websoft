<!-- Content area -->
<div class="content">
 <div class="container-detached">
    <div class="content-detached">
      <div class="panel panel-flat">
        <div class="panel-body">
          <div class="row">
              	<!-- Start add new ctegory-->
            <div class="row">
                <div class="col-md-12">
                  <div class="panel panel-flat">
                        <div class="panel-heading">
                                <h6 class="panel-title"><?php echo $subtitle;?></h6>
                                <div class="heading-elements">
                                        <ul class="icons-list">

                                        </ul>
                                  </div>
                        </div>

                        <div class="panel-body">
                         
                            <form action="<?php echo base_url();?>claim/ImportExcel" id="ImportClaimForm" method="POST" enctype="multipart/form-data">
                                <div class="row">
                                   
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Choose File<span style="color:red;">*</span></label>
                                          <div class="file-upload">
                                              <div class="file-select">
                                                <div class="file-select-button" id="fileName">Choose File</div>
                                                <div class="file-select-name" id="noFile">No file chosen...</div> 
                                                <input type="file" name="chooseFile" id="chooseFile" required="">
                                              </div>
                                            </div>
                                           <span class="help-block">Please Select xls file to import Claim Data.</span>
                                         </div>
                                    </div>
                                   
                                     
                                    <div class="col-md-2">
                                         <button style="margin: 26px 0 0 0;" class="btn btn-info" type="button" name="save" id="uploadBtn" disabled="disabled" ><i class="fa fa-upload" ></i>&nbsp; Upload</button>
                                    </div>
                                   
                                    <div class="col-md-4">
                                         <button style="margin: 26px 0 0 0;" class="btn btn-success downloadfile"  type="button" name="download" ><i class="fa fa-download" ></i>&nbsp; Download Sample Format</button>
                                         <span class="help-block">Click to download sample file</span>
                                    </div>
                                  </div>
                                   
                             </form>
                           
                            
                           
                         </div>
                      </div>
                    </div>
                </div>
                 <!-- End add new Produt-->
                 
               
          </div> 
       </div>
      </div>
    </div>
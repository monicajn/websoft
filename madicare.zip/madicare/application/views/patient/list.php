<!-- Content area -->
				<div class="content">
					
                                        	 <!-- Start builder list -->
					<div class="panel panel-flat">
						<div class="panel-heading">
							<h5 class="panel-title"><?php echo $subtitle;?></h5>
                              <div class="heading-elements">
								<ul class="icons-list">
									<?php  if($this->CI->checkPermission('pt_1')){ ?>
                                      <li><a href="#" data-src="patient/add" class="btn btn-success redirect"><i class="icon-plus3"></i>&nbsp;New Patient</a></li>
                                      <?php } ?>
                                </ul>
		                      </div>
							
						</div>

						<div class="panel-body">
                             <div class="table-responsive">                               
                              <table id="example" class="table table-bordered" cellspacing="0" width="100%"> 
									<thead>
								        <tr>
								        	<?php if($this->CI->checkPermission('pt_2')){ ?>	
								        	<th style="width: 30px"><label class="checkbox-inline">
                                               <input type="checkbox" name="checkAll" id="checkAll" class="styled checkAll" value="All">
                                            </label></th>
                                            <?php } ?>
								            <th>PatientID</th>
								            <th>Name</th>
								            <th>Email</th>
								           <th>Mobile</th>
								             <th>DOB</th>
								            <th>City </th>
								            <th>State</th>
		                                   <th>Action</th>
								        </tr>
								    </thead>
								    <tbody>
		                                 <?php foreach ($patients as $row ) { 
		                                 	if($row['dob']!=''){ $dob = $this->CI->createFormatDate($row['dob'],'Y-m-d','m/d/Y'); }else{$dob='';}?>
								    		<tr>
								    		<?php if($this->CI->checkPermission('pt_2')){ ?>	
								    		<td class="text-center" style="width: 30px">
								    		   <label class="checkbox-inline tdinline">
                                                  <input type="checkbox" name="pids[]" class="styled tdcheck" value="<?php echo $row['id'];?>">
                                              </label>
								    		</td>
								    	   <?php } ?>
		                                 	<td><b><a href="#"><?php echo $row['patientID'];?></a></b></td>
								            <td><?php echo $row['fname']." ".$row['mname']." ".$row['lname'];?></td>
								            <td><?php echo $row['email'];?></td>
								            <td><?php echo $row['mobile'];?></td>
								            <td><?php echo $dob;?></td>
								            <td><?php echo $row['city'];?></td>
		                                    <td><?php echo $row['state'];?></td>
							               <td >
							               	<?php  if($this->CI->checkPermission('pt_4')){ ?>
							               	    <a href="#" class="btn btn-primary btn-xs view" data-id="<?php echo $row['id'];?>" onclick="showmodel('<?php echo base_url("patient/popup/viewpatient/".$row['id']);?>','Patient Details  -(<?php echo $row['patientID'];?>)','FALSE','','');"><i class="fa fa-eye" ></i></a>
										      <?php } ?>  
										      <?php if($this->CI->checkPermission('pt_2')){ ?>
										          <a href="#"  data-src="patient/edit/<?php echo $row['id'];?>"  class="btn btn-info btn-xs redirect" data-id="<?php echo $row['id'];?>" ><i class="fa fa-edit"></i></a>
										       <?php } ?>
										       <?php if($this->CI->checkPermission('pt_3')){ ?>
										          <a class="btn btn-danger btn-xs delete" data-id="<?php echo $row['id'];?>"><i class="fa fa-trash"></i></a>
										       <?php }?>
									       </td>
								        </tr>           
								       <?php } ?>          
								       
								    </tbody>
								</table>
							</div>
							<?php if($this->CI->checkPermission('pt_3')){ ?>
							<div class="row">
                             	<div class="col-md-3">
                             	<select name="action" id="action" class="form-control">
                             		<option value="delete">delete</option>
                             	</select>
                             	</div>
                             	 <div class="col-md-2"><button type="button" name="go" id="go" class="btn btn-success">action</button> </div>
                             </div> 
                            <?php } ?>
						</div>
					</div>
                                                <!-- end builder list -->
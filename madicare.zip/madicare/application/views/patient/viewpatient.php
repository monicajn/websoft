<?php  $join=array('states'=>'states.id=patients.state_id','cities'=>'cities.id=patients.city_id');
$pdata = $this->Patient_model->getResult(array('states.name AS state','cities.name AS city','patients.*'),array('patients.id'=>$param2),$join);?>

<div class="row">
    <div class="col-md-12" id="errormsg"></div>
</div>
<div class="row">
    <div class="col-md-12">
       <div class="table-responsive content-group">
         <table class="table table-bordered table-striped">
              <thead>
                          
                            <tr>
                                <th >User-ID</th>
                                 <td> <?php  echo $pdata[0]['patientID'] ;?></td>
                              </tr>
                              
                               <tr>
                                   <th >Name</th>
                                    <td> <?php  echo $pdata[0]['fname']." ".$pdata[0]['mname']." ".$pdata[0]['lname'] ;?></td>
                              </tr>
                               <tr>
                                   <th >DOB</th>
                                    <td> <?php  echo $pdata[0]['dob'] ;?></td>
                              </tr>
                               <tr>
                                   <th >Email</th>
                                    <td> <?php  echo $pdata[0]['email'] ;?></td>
                              </tr>
                              <tr>
                                   <th >Mobile No</th>
                                    <td> <?php  echo $pdata[0]['mobile'] ;?></td>
                              </tr>
                               <tr>
                                   <th >Insurance company </th>
                                    <td> <?php  echo $pdata[0]['insurance_company'] ;?></td>
                              </tr>
                               <tr>
                                   <th >insurance member id</th>
                                    <td> <?php  echo $pdata[0]['insurance_member_id'] ;?></td>
                              </tr>
                              <tr>
                                   <th >Insurance phone</th>
                                    <td> <?php  echo $pdata[0]['insurance_phone'] ;?></td>
                              </tr>
                              <tr>
                                 <th>State</th>
                                 <td> <?php  echo $pdata[0]['state'] ;?></td>
                                 </tr>
                              <tr>
                                 <th>City</th>
                                 <td> <?php  echo $pdata[0]['city'] ;?></td>
                              </tr>
                               <tr>
                                 <th>Address</th>
                                 <td> <?php  echo $pdata[0]['address'] ;?></td>
                              </tr>
                              
                    </thead>
                    <tbody>
                        
                           
                    </tbody>
                    
            </table>
        </div>
    </div>
</div>


<!-- Content area -->
				<div class="content">
					<!-- Start add new builder-->
					<div class="row">
              <div class="col-md-12">
				              <div class="panel panel-flat">
                            <div class="panel-heading">
                                    <h6 class="panel-title"><?php echo $subtitle;?></h6>
                                   <div class="heading-elements">
                                      <ul class="icons-list">
                                        <li><a href="#" data-src="patient" class="btn btn-default redirect"><i class="icon-undo2"></i>&nbsp;Back to Patient List</a></li>
                                    </ul>
                                   </div>
                            </div>

				              <div class="panel-body">
                          <form action="#" id="AddPatientForm" method="POST">
                            <div id="errormsg"></div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>First Name<span style="color:red;">*</span></label>
                                            <input type="text" name="fname" id="fname" class="form-control checkempty" placeholder="Enter First Name">
                                         </div>
                                        </div>

                                        <div class="col-md-4">
                                                <div class="form-group">
                                                  <label>Middle Name</label>
                                                  <input type="text" name="mname" id="mname" class="form-control" placeholder="Enter Middle Name">
                                                 </div>
                                        </div>
                                        <div class="col-md-4">
                                           <div class="form-group">
                                              <label>Last Name<span style="color:red;">*</span></label>
                                                  <input type="text" name="lname" id="lname" class="form-control checkempty" placeholder="Enter Last Name">
                                            </div>
                                        </div>    
                                </div>
                               
                               <div class="row">
                                   <div class="col-md-4">
                                        <div class="form-group">
                                              <label class="display-block text-semibold">SEX</label>
                                               <label class="radio-inline" style="">
                                                 <input type="radio" value="M" name="sex" class="styled " checked="">
                                                    Male
                                                </label>
                                                 <label class="radio-inline" style="">
                                                 <input type="radio" value="F" name="sex" class="styled" >
                                                   Female
                                                </label>
                                                <label class="radio-inline " style="">
                                                 <input type="radio" value="O" name="sex" class="styled" >
                                                   Other
                                                </label>
                                         </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                              <label class="display-block text-semibold">Pregnant</label>
                                               <label class="radio-inline " style="">
                                                 <input type="radio" value="Yes" name="pregnant" class="styled " >
                                                    YES
                                                </label>
                                                 <label class="radio-inline " style="">
                                                 <input type="radio" value="No" name="pregnant" class="styled" >
                                                   NO
                                                </label>
                                                <label class="radio-inline " style="">
                                                 <input type="radio" value="N/A" name="pregnant" class="styled" checked="">
                                                   N/A
                                                </label>
                                         </div>
                                      </div>
                                </div>
                                                                                       
                               <div class="row">
                                   <div class="col-md-4">
                                        <div class="form-group">
                                              <label>DOB</label>
                                              <input type="text" name="dob" id="dob" class="form-control datepicker" placeholder="Enter DOB" disabled="">
                                         </div>
                                        </div>
                                    <div class="col-md-4">
                                         <div class="form-group">
                                              <label>Email</label>
                                               <input type="text" name="email" id="email" class="form-control" placeholder="Enter  Email">
                                         </div>
                                        </div>

                                        
                                        <div class="col-md-4">
                                                <div class="form-group">
                                                  <label>Mobile No</label>
                                                  <input type="text" name="mobile" id="mobiles" class="form-control mobilemask" placeholder="Enter Mobile No">
                                                 </div>
                                        </div>

                                    </div>

                                    <div class="row">
                                   <div class="col-md-4">
                                        <div class="form-group">
                                              <label>Insurance company</label>
                                               <select name="insurance_company" id="insurance_company" style="width: 100%;" class="select2"  >
                                                    <option value="">-select-</option>
                                                    <?php foreach ($insurance as $row) { ?>
                                                        <option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
                                                   <?php }?>
                                               </select>
                                         </div>
                                        </div>
                                    <div class="col-md-4">
                                         <div class="form-group">
                                              <label>insurance member id</label>
                                               <input type="text" name="insurance_member_id" id="insurance_member_id" class="form-control" placeholder="Enter insurance member ID">
                                         </div>
                                        </div>

                                        
                                        <div class="col-md-4">
                                                <div class="form-group">
                                                  <label>Insurance phone</label>
                                                  <input type="text" name="insurance_phone" id="insurance_phone" class="form-control mobilemask" placeholder="Enter Insurance phone">
                                                 </div>
                                        </div>

                                    </div>
                               
                                <div class="row">
                                       <div class="col-md-4">
                                          <div class="form-group">
                                              <label>State</label>
                                                 <select name="state_id" id="state_id" style="width: 100%;" class="select2"  >
                                                          <option value="">-select-</option>
                                                            <?php foreach($states as $row){?>
                                               <option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
                                               <?php } ?>
                                                 </select>
                                           </div>
                                        </div>

                                        <div class="col-md-3">
                                          <div class="form-group">
                                              <label>City</label>
                                                      <select name="city_id" id="city_id" style="width: 100%;" class="select2"  >
                                                      <option value="">-select-</option>

                                             </select>
                                             
                                           </div>
                                        </div>
                                         <div class="col-md-1">
                                           <button  type="button" class="btn btn-info" style="margin:25px 0 0 0;"  onclick="showmodel('<?php echo base_url("crud/citypopup/addcity/".$row['id']);?>','ADD CITY','TRUE','AddcityForm','crud/addcity');"><i class="fa fa-plus"></i></button>
                                         </div>
                                        <div class="col-md-4">
                                                <div class="form-group">
                                                   <label> Zipcode</label>
                                                   <input type="text" name="zipcode" id="zipcode" class="form-control" placeholder="Enter Zipcode">
                                                 </div>
                                        </div>
                                </div>
                                  <div class="row">
                                       
                                        <div class="col-md-4">
                                                <div class="form-group">
                                                   <label> Address</label>
                                                   <input type="text" name="address" id="address" class="form-control" placeholder="Enter Address">
                                                 </div>
                                        </div>
                                </div>

                                            
				

                     <div class="text-right">
                       <button type="submit" name="save" class="btn btn-primary">Submit <i class="icon-arrow-right14 position-right"></i></button>
                     </div>
                  </form>
							    </div>
							</div>
						</div>
					</div>
                                        
         
					<!-- End add new builder-->
                                        	 
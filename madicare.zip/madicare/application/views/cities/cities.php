<!-- Content area -->
<div class="content">
 <div class="container-detached">
    <div class="content-detached">
      <div class="panel panel-flat">
        <div class="panel-body">
          <div class="row">
              	<!-- Start add new ctegory-->
            <div class="row">
                <div class="col-md-12">
                  <div class="panel panel-flat">
                        <div class="panel-heading">
                                <h6 class="panel-title"><?php echo $subtitle;?></h6>
                                <div class="heading-elements">
                                        <ul class="icons-list">

                                        </ul>
                                  </div>
                        </div>

                        <div class="panel-body">
                          <?php if($this->CI->checkPermission('ct_1')){ ?>
                            <form action="#" id="AddcityForm" method="POST" enctype="multipart/form-data">
                                <div class="row">
                                   
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>City<span style="color:red;">*</span></label>
                                            <input type="text" name="name" id="name" class="form-control" placeholder="Enter City name">
                                         </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                          <label>State<span style="color:red;">*</span></label>
                                           <select name="state_id" id="state_id" style="width: 100%;" class="select2"  >
                                                          <option value="">-select-</option>
                                                            <?php foreach($states as $row){?>
                                               <option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
                                               <?php } ?>
                                           </select>
                                        </div>
                                    </div>
                                    
                                     
                                    <div class="col-md-2">
                                         <button style="margin: 26px 0 0 0;" class="btn btn-success" type="submit" name="save" id="save" >SAVE</button>
                                      </div>
                                  </div>
                                   
                             </form>
                             <?php } ?>
                             <div class="row">
                                <form action="#" id="searchcityForm" method="POST" enctype="multipart/form-data">
                                <div class="row">
                                   
                                 <div class="col-md-4">
                                        <div class="form-group">
                                          <label class="text-info">Select State to search city<span style="color:red;"></span></label>
                                           <select name="_state_id" id="_state_id" style="width: 100%;" class="select2"  >
                                                          <option value="all">-select-</option>
                                                            <?php foreach($states as $row){?>
                                       <option value="<?php echo $row['id'];?>" <?php if(isset($_POST['search'])) { if($row['id']==$_POST['_state_id']){echo "selected";} }?>>
                                               <?php echo $row['name'];?></option>
                                               <?php } ?>
                                           </select>
                                        </div>
                                    </div>
                                    
                                     
                                    <div class="col-md-2">
                                         <button style="margin: 26px 0 0 0;" class="btn btn-success" type="submit" name="search" id="search" >Search city</button>
                                      </div>
                                  </div>
                                   
                             </form>
                              </div>
                            <div class="row">
                                <div class="table-responsive">                               
                                    <table id="example" class="table table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                                <tr>
                                                        <th>City</th>
                                                        <th>State</th>
                                                        <th>Action</th>
                                                </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=1;foreach($cities as $row) { ?>
                                                <tr>
                                                       
                                                        <td><?php echo $row['name'];?></td>
                                                        <td><?php echo $row['sname'];?></td>
                                                       
                                                        <td class="text-center">
                                                          <?php if($this->CI->checkPermission('ct_2')){ ?>
                                                           <button type="button" class="btn btn-primary btn-icon" onclick="showmodel('<?php echo base_url("cities/popup/editcities/".$row['id']);?>','Update City  -(<?php echo $row['name'];?>)','TRUE','AddcityForm','cities/edit');"><i class="fa fa-edit"></i></button>
                                                           <?php } 
                                                           if($this->CI->checkPermission('ct_3')){ ?>
                                                            <button type="button" class="btn btn-danger btn-icon delete" data-id="<?php echo $row['id'];?>"><i class="fa fa-trash"></i></button>
                                                            <?php } ?>
                                                            
                                                        </td>
                                                </tr>
                                            <?php $i++;} ?>   
                                        </tbody>
                                </table>
                            </div>
                            </div>
                         </div>
                      </div>
                    </div>
                </div>
                 <!-- End add new Produt-->
                 
               
          </div> 
       </div>
      </div>
    </div>
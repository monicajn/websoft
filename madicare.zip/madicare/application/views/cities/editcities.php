<?php  $Data = $this->Cities_model->getResult(array('*'),array('id'=>$param2));
$states=$this->States_model->getResult(array('*'),array('country_id'=>'231'));?>
<input type="hidden" name="id" value="<?php echo $param2;?>"/>
<div class="row">
    <div class="col-md-12"><!-- col6 2nd start-->
         <div class="form-group">
            <div class="row">
                <div class="col-sm-6">
                        <label>City</label>
                        <input required name="name" id="name" type="text" placeholder="Enter City name" class="form-control" value="<?php echo $Data[0]['name'];?>">
                </div>
                  <div class="col-sm-6">
                        <label>State</label>
                        <select name="state_id" id="state_id" style="width: 100%;" class="select2"  >
                                <option value="">-select-</option>
                                 <?php foreach($states as $row){?>
                                       <option value="<?php echo $row['id'];?>" <?php if($row['id']==$Data[0]['state_id']){echo "selected";}?>>
                                        <?php echo $row['name'];?>
                                          
                                        </option>
                                 <?php } ?>
                          </select>
                </div>
                
            </div>
            
         </div>
        
         
     </div><!-- col6 2nd end-->  
     
  </div> 
<script type="text/javascript">
  $(".select2").select2({
               placeholder: "select",
               allowClear: true
             });
</script>
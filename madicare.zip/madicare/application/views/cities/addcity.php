<?php $states=$this->States_model->getResult(array('*'),array('country_id'=>'231'));?>
<div class="row">
    <div class="col-md-12"><!-- col6 2nd start-->
         <div class="form-group">
            <div class="row">
                <div class="col-sm-6">
                        <label>City</label>
                        <input required name="cityname" id="cityname" type="text" placeholder="Enter City Name" class="form-control" value="">
                </div>
                  <div class="col-sm-6">
                        <label>State</label>
                        <select name="stateid" id="stateid" style="width: 100%;" class="select2"  >
                                <option value="">-select-</option>
                                 <?php foreach($states as $row){?>
                                       <option value="<?php echo $row['id'];?>"><?php echo $row['name'];?> </option>
                                 <?php } ?>
                          </select>
                </div>
                
            </div>
            
         </div>
        
         
     </div><!-- col6 2nd end-->  
     
  </div> 
<script type="text/javascript">
  $(".select2").select2({
               placeholder: "select",
               allowClear: true
             });

  
</script>
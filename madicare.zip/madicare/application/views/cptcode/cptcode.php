<!-- Content area -->
<div class="content">
 <div class="container-detached">
    <div class="content-detached">
      <div class="panel panel-flat">
        <div class="panel-body">
          <div class="row">
              	<!-- Start add new ctegory-->
            <div class="row">
                <div class="col-md-12">
                  <div class="panel panel-flat">
                        <div class="panel-heading">
                                <h6 class="panel-title"><?php echo $subtitle;?></h6>
                                <div class="heading-elements">
                                        <ul class="icons-list">

                                        </ul>
                                  </div>
                        </div>

                        <div class="panel-body">
                          <?php if($this->CI->checkPermission('cpt_1')){ ?>
                            <form action="#" id="AddCptForm" method="POST" enctype="multipart/form-data">
                                <div class="row">
                                   
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>CPT code<span style="color:red;">*</span></label>
                                            <input type="text" name="code" id="code" class="form-control" placeholder="Enter CPT code">
                                         </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                          <label>Rate<span style="color:red;">*</span></label>
                                          <input type="text" name="rate" id="rate" class="form-control" placeholder="Enter Rate" value="">
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label>Description<span style="color:red;">*</span></label>
                                            <input type="text" name="description" id="description" class="form-control" placeholder="Enter Description">
                                         </div>
                                    </div>
                                     
                                    <div class="col-md-2">
                                         <button style="margin: 26px 0 0 0;" class="btn btn-success" type="submit" name="save" id="save" >SAVE</button>
                                      </div>
                                  </div>
                                </form>
                            <?php } ?>
                            <div class="row">
                                <div class="table-responsive">                               
                                    <table id="example" class="table table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                                <tr>
                                                        <th>CPT Code</th>
                                                        <th>Rate</th>
                                                        <th>Description</th>
                                                        <th>Action</th>
                                                </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=1;foreach($cptcodes as $row) { ?>
                                                <tr>
                                                       
                                                        <td><?php echo $row['code'];?></td>
                                                        <td><?php echo $row['rate'];?></td>
                                                        <td><?php echo $row['description'];?></td>
                                                        
                                                        <td class="text-center">
                                                           <?php if($this->CI->checkPermission('cpt_2')){ ?>
                                                            <button type="button" class="btn btn-primary btn-icon" onclick="showmodel('<?php echo base_url("cptcode/popup/editcptcode/".$row['id']);?>','Update CPT-code  -(<?php echo $row['code'];?>)','TRUE','EditCptForm','cptcode/edit');"><i class="fa fa-edit"></i></button>
                                                            <?php } ?>
                                                          <?php if($this->CI->checkPermission('cpt_3')){ ?>
                                                            <button type="button" class="btn btn-danger btn-icon delete" data-id="<?php echo $row['id'];?>"><i class="fa fa-trash"></i></button>
                                                          <?php } ?>

                                                            
                                                        </td>
                                                </tr>
                                            <?php $i++;} ?>   
                                        </tbody>
                                </table>
                            </div>
                            </div>
                         </div>
                      </div>
                    </div>
                </div>
                 <!-- End add new Produt-->
                 
               
          </div> 
       </div>
      </div>
    </div>
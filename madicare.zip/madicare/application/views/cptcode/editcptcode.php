<?php  $Data = $this->Cptcode_model->getResult(array('*'),array('id'=>$param2));?>
<input type="hidden" name="id" value="<?php echo $param2;?>"/>
<div class="row">
    <div class="col-md-12"><!-- col6 2nd start-->
         <div class="form-group">
            <div class="row">
                <div class="col-sm-6">
                        <label>CPT code </label>
                        <input required name="ecode" id="ecode" type="text" placeholder="Enter CPT code" class="form-control" value="<?php echo $Data[0]['code'];?>">
                </div>
                  <div class="col-sm-6">
                        <label>Rate</label>
                        <input required name="erate" id="erate" type="text" placeholder="Enter Rate" class="form-control" value="<?php echo $Data[0]['rate'];?>">
                </div>
                
            </div>
            <div class="row">
              <div class="col-sm-12">
                        <label>Description</label>
                        <input required name="edescription" id="edescription" type="text" placeholder="Enter description" class="form-control" value="<?php echo $Data[0]['description'];?>">
                </div>
            </div>
         </div>
        
         
     </div><!-- col6 2nd end-->  
     
  </div> 
